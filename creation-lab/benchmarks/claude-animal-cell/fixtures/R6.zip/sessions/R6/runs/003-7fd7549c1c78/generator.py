"""Blockout v3 de la celula animal (benchmark Claude v1, replica R6).

Correccion 2 de 2 sobre v2 tras la revision ciega 002-6cafed66f0c4. Cambios:
- Corte frontal por debajo del centro: el borde -Y baja FRONT_DROP=0.09 m en
  la envoltura (desde z=0.055 hasta z=-0.035). El desplazamiento es monotono
  por columna (x,y fijos) y se aplica solo sobre z>FRONT_Z0, de modo que la base
  no cambia. Envoltura y citosol usan el mismo mapa, asi la contencion se conserva.
- Golgi (pila magenta) y vesiculas cerca del Golgi, en la zona ya descubierta.
- Mitocondrias alargadas separadas de la pared: una abierta, una cerrada.
- REL como tubos ramificados (tres elipsoides unidos) en color propio.
- Lisosomas mayores y de color contrastado.
- Citoesqueleto: dos filamentos cortos lejos del nucleo.
- Centrosoma: dos cilindros cortos perpendiculares junto al nucleo.

Solo blockout. Usa solo la biblioteca components; no importa bpy, no crea luces
ni camaras, no guarda ni exporta archivos. Las piezas que no se transforman
(orgulos) se comprueban contra la cavidad abierta con la inversa del mapa.
"""
import math

from components import CutawayProfile, FlattenedCisterna, MeshData, material, mesh_object, sphere

LONGEST = 0.30                 # metros; dimension mayor tras normalizar vertices.
PART_TRIANGLE_BUDGET = 8000    # limite por objeto de este generador.
FRONT_DROP = 0.09              # descenso del borde frontal en unidades de diseno.
FRONT_Z0 = -0.05               # por debajo de esta altura la base no se mueve.
FRONT_SPAN = 0.11              # radio Y de la envoltura en unidades de diseno.
CAMERA = (0.45, -0.60, 0.55)   # camara comun del brief.
RIB_R = 0.0050                 # radio de ribosoma en unidades de diseno.

ENVELOPE = CutawayProfile(radii=(0.13, 0.11, 0.10), cut_fraction=0.55, wall_fraction=0.06)
CYTOSOL = ENVELOPE.fill(clearance=0.08, inset=0.75, segments=32, rings=12)

NUCLEUS = CutawayProfile(radii=(0.058, 0.050, 0.046), center=(-0.03, 0.03, 0.0),
                         cut_fraction=0.5, wall_fraction=0.12)
RER_RADII = (0.032, 0.023, 0.007)
RER_A = FlattenedCisterna(radii=RER_RADII, wave=0.002, center=(0.062, 0.030, 0.014))
RER_B = FlattenedCisterna(radii=RER_RADII, wave=0.002, center=(0.062, 0.030, -0.012))
RER_ANCHORS = [(3, 4), (3, 12), (3, 20), (3, 28), (6, 8), (6, 16), (6, 24)]  # (j, i) en rejilla 16x32

FREE_RIBOSOMES = [(-0.095, 0.020, 0.015), (-0.050, -0.050, -0.005), (0.000, -0.050, -0.005),
                  (0.090, 0.020, 0.000), (-0.045, 0.085, 0.000), (0.020, -0.020, 0.020),
                  (-0.020, -0.060, -0.045)]
LYSOSOMES = [(-0.080, 0.000, -0.035), (-0.095, -0.020, -0.030), (0.035, -0.035, -0.050)]
VESICLES = [(0.050, -0.062, -0.010), (0.012, -0.062, -0.012), (0.070, -0.030, -0.030),
            (-0.010, -0.045, -0.040)]

PARTS_META = [
    ('membrana', (0.10, 0.45, 0.50), 0.45),
    ('citoplasma', (0.95, 0.90, 0.75), 0.70),
    ('nucleo', (0.25, 0.42, 0.85), 0.45),
    ('nucleolo', (0.45, 0.15, 0.55), 0.50),
    ('ribosomas', (0.15, 0.12, 0.10), 0.60),
    ('rer', (0.20, 0.55, 0.30), 0.50),
    ('rel', (0.55, 0.90, 0.85), 0.50),
    ('golgi', (0.90, 0.25, 0.65), 0.50),
    ('mitocondrias', (0.85, 0.25, 0.15), 0.45),
    ('lisosomas', (1.00, 0.85, 0.05), 0.35),
    ('centrosoma', (0.55, 0.55, 0.75), 0.50),
    ('vesiculas', (0.30, 0.80, 0.95), 0.40),
    ('citoesqueleto', (0.55, 0.45, 0.35), 0.60),
]


def _front_drop_factor(y, z):
    g = min(1.0, max(0.0, -y / FRONT_SPAN))
    w = min(1.0, max(0.0, (z - FRONT_Z0) / (ENVELOPE.cut_z - FRONT_Z0)))
    return FRONT_DROP * g * w


def _front_drop(mesh):
    """Baja el borde frontal de la envoltura y del citosol.

    Por columna (x,y fijos) z' = z - FRONT_DROP*g(y)*w(z) con w(z) lineal entre
    FRONT_Z0 y el corte. Es monotona en z (derivada >0), asi que conserva el orden
    de capas y la orientacion de las caras.
    """
    def move(p):
        x, y, z = p
        if z <= FRONT_Z0:
            return (x, y, z)
        return (x, y, z - _front_drop_factor(y, z))
    return MeshData(tuple(move(v) for v in mesh.vertices), mesh.faces)


def _rot_z(mesh, angle, center):
    c, s = math.cos(angle), math.sin(angle)
    cx, cy, cz = center

    def move(p):
        x, y, z = p[0] - cx, p[1] - cy, p[2] - cz
        return (cx + c * x - s * y, cy + s * x + c * y, cz + z)
    return MeshData(tuple(move(v) for v in mesh.vertices), mesh.faces)


def _combine(meshes):
    vertices, faces = [], []
    for mesh in meshes:
        offset = len(vertices)
        vertices.extend(mesh.vertices)
        faces.extend(tuple(i + offset for i in face) for face in mesh.faces)
    return MeshData(tuple(vertices), tuple(faces))


def _compose():
    """Piezas en el marco de diseno: {part_id: [(nombre, MeshData, smooth)]}."""
    parts = {}

    parts['membrana'] = [('envoltura con borde frontal bajo', _front_drop(ENVELOPE.shell(segments=32, rings=12)), False)]
    parts['citoplasma'] = [('citosol palido', _front_drop(CYTOSOL), False)]

    nucleus = NUCLEUS.shell(segments=28, rings=12)
    nucleolus = sphere((0.013, 0.012, 0.012), center=(-0.026, 0.034, -0.002), segments=16, rings=8)
    parts['nucleo'] = [('envoltura parcial', nucleus, False)]
    parts['nucleolo'] = [('nucleolo', nucleolus, True)]

    rer_a = RER_A.mesh(segments=32, rings=16)
    rer_b = RER_B.mesh(segments=32, rings=16)
    anchors = []
    for j, i in RER_ANCHORS:
        center, _normal = RER_A.anchor(math.pi * j / 16, math.tau * i / 32, offset=RIB_R)
        anchors.append(sphere((RIB_R,) * 3, center=center, segments=8, rings=4))
    free = [sphere((RIB_R,) * 3, center=c, segments=8, rings=4) for c in FREE_RIBOSOMES]
    parts['rer'] = [('cisternas lamelares con ribosomas', _combine([rer_a, rer_b]), True)]
    parts['ribosomas'] = [('libres y anclados', _combine(anchors + free), True)]

    branches = []
    for center, length, radius, angle in (((-0.065, -0.040, -0.010), 0.016, 0.0075, 0.5),
                                          ((-0.045, -0.052, -0.005), 0.014, 0.0070, -0.6),
                                          ((-0.058, -0.062, -0.020), 0.010, 0.0060, 1.2)):
        tube = sphere((length, radius, radius), center=center, segments=12, rings=6)
        branches.append(_rot_z(tube, angle, center))
    parts['rel'] = [('tubulos ramificados sin ribosomas', _combine(branches), True)]

    golgi = []
    for k in range(4):
        sheet = FlattenedCisterna(radii=(0.022 - 0.002 * k, 0.016 - 0.002 * k, 0.004), wave=0.002,
                                  center=(0.020 + 0.003 * k, -0.035 - 0.003 * k, -0.030 + 0.008 * k))
        golgi.append(sheet.mesh(segments=24, rings=12))
    parts['golgi'] = [('pila curva de cisternas', _combine(golgi), True)]

    mito_open = CutawayProfile(radii=(0.024, 0.012, 0.012), center=(-0.085, -0.012, 0.0),
                               cut_fraction=0.4, wall_fraction=0.2).shell(segments=20, rings=8)
    mito_closed = sphere((0.024, 0.011, 0.011), center=(-0.060, -0.030, -0.020), segments=16, rings=8)
    parts['mitocondrias'] = [('mitocondria abierta', mito_open, False),
                             ('mitocondria cerrada', mito_closed, True)]

    parts['lisosomas'] = [('lisosomas', _combine(
        [sphere((0.013,) * 3, center=c, segments=10, rings=6) for c in LYSOSOMES]), True)]

    centriole_a = sphere((0.014, 0.0045, 0.0045), center=(-0.005, 0.080, 0.015), segments=10, rings=6)
    centriole_b = sphere((0.0045, 0.014, 0.0045), center=(-0.005, 0.080, 0.027), segments=10, rings=6)
    parts['centrosoma'] = [('centriolos perpendiculares', _combine([centriole_a, centriole_b]), True)]

    parts['vesiculas'] = [('vesiculas', _combine(
        [sphere((0.007,) * 3, center=c, segments=8, rings=4) for c in VESICLES]), True)]

    rods = []
    for center, length, angle in (((-0.060, 0.060, 0.040), 0.025, 0.3),
                                  ((0.072, 0.055, 0.022), 0.022, -0.4)):
        rod = sphere((length, 0.003, 0.003), center=center, segments=8, rings=4)
        rods.append(_rot_z(rod, angle, center))
    parts['citoesqueleto'] = [('filamentos finos', _combine(rods), True)]
    return parts


def _normalize(parts):
    """Escala y centra todas las piezas segun sus vertices reales."""
    verts = [v for items in parts.values() for _n, mesh, _s in items for v in mesh.vertices]
    lo = [min(v[k] for v in verts) for k in range(3)]
    hi = [max(v[k] for v in verts) for k in range(3)]
    scale = LONGEST / max(hi[k] - lo[k] for k in range(3))
    center = [(lo[k] + hi[k]) / 2 for k in range(3)]

    def move(p):
        return tuple((p[k] - center[k]) * scale for k in range(3))
    out = {}
    for pid, items in parts.items():
        out[pid] = [(name, MeshData(tuple(move(v) for v in mesh.vertices), mesh.faces), smooth)
                    for name, mesh, smooth in items]
    return out


def _label(parts, pid, cam):
    best = None
    for _name, mesh, _smooth in parts[pid]:
        for v in mesh.vertices:
            depth = sum(v[k] * cam[k] for k in range(3))
            if best is None or depth > best:
                best, point = depth, v
    return [round(point[k] + 0.004 * cam[k], 5) for k in range(3)]


def build():
    cam_norm = math.sqrt(sum(c * c for c in CAMERA))
    cam = tuple(c / cam_norm for c in CAMERA)
    parts = _normalize(_compose())
    for pid, color, roughness in PARTS_META:
        mat = material(pid, color, roughness=roughness)
        for name, mesh, smooth in parts[pid]:
            mesh_object(name, pid, mesh, mat, smooth=smooth, max_triangles=PART_TRIANGLE_BUDGET)
    return {
        'title': 'Celula animal, blockout con borde frontal bajo (v3)',
        'design_notes': [
            'Blockout: envoltura abierta por arriba y con borde frontal bajo el centro; los organulos quedan visibles desde la camara comun.',
            'Citosol palido como volumen inferior; el nucleo tiene envoltura parcial y el nucleolo es visible dentro.',
            'RER junto al nucleo con cisternas lamelares y ribosomas anclados; REL en tubos ramificados sin ribosomas.',
            'Golgi apilado mas alejado que el RER; vesiculas cercanas; mitocondrias alargadas, una abierta.',
            'Centrosoma cerca del nucleo con dos centriolos perpendiculares; citoesqueleto escaso en dos filamentos.',
            'Blockout de disposicion: no es detalle final ni validacion biologica; escala de maqueta 0.30 m.',
        ],
        'parts': {pid: {'label_position': _label(parts, pid, cam)} for pid, _c, _r in PARTS_META},
    }
