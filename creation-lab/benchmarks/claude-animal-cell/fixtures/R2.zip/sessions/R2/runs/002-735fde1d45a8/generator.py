"""Detail v1 · animal cell (13 parts), built on the approved blockout-v1 layout.

Layout is authored in a LOCAL frame (cut plane horizontal, floor = cytoplasm fill).
At the end the whole scene is tilted about X so the opening faces up and to the
front (-Y), then centred and uniformly scaled so the real vertices measure 0.30 m.
"""
import math
from components import (CutawayProfile, FlattenedCisterna, MeshData, sphere,
                        material, mesh_object)

TILT = math.radians(42.0)
TAU = math.tau

MATS = {
    'membrana': ((0.86, 0.45, 0.30), 0.45),
    'citoplasma': ((0.95, 0.92, 0.68), 0.7),
    'nucleo': ((0.38, 0.25, 0.68), 0.5),
    'cromatina': ((0.66, 0.58, 0.90), 0.7),
    'nucleolo': ((0.45, 0.06, 0.38), 0.5),
    'ribosomas': ((0.03, 0.03, 0.10), 0.5),
    'rer': ((0.25, 0.58, 0.95), 0.5),
    'crestas': ((0.98, 0.62, 0.22), 0.5),
    'poros': ((0.18, 0.08, 0.38), 0.5),
    'banda': ((0.22, 0.14, 0.08), 0.5),
    'rel': ((0.30, 0.82, 0.80), 0.5),
    'golgi': ((0.95, 0.72, 0.10), 0.45),
    'mitocondrias': ((0.86, 0.20, 0.12), 0.5),
    'lisosomas': ((0.25, 0.68, 0.22), 0.5),
    'centrosoma': ((0.40, 0.26, 0.15), 0.5),
    'vesiculas': ((0.96, 0.52, 0.74), 0.45),
    'citoesqueleto': ((0.20, 0.22, 0.28), 0.5),
}


# ---------------------------------------------------------------- helpers
def _tf(mesh, fn):
    return MeshData(tuple(fn(v) for v in mesh.vertices), mesh.faces)


def _merge(meshes):
    verts, faces = [], []
    for m in meshes:
        off = len(verts)
        verts.extend(m.vertices)
        faces.extend(tuple(i+off for i in f) for f in m.faces)
    return MeshData(tuple(verts), tuple(faces))


def _rz(p, a):
    c, s = math.cos(a), math.sin(a)
    return (p[0]*c-p[1]*s, p[0]*s+p[1]*c, p[2])


def _norm(v):
    n = math.sqrt(sum(x*x for x in v))
    return tuple(x/n for x in v)


def _cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def _dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def _spline(points, sub=6):
    """Uniform Catmull-Rom through the points."""
    pts = [points[0]]+list(points)+[points[-1]]
    out = []
    for i in range(1, len(pts)-2):
        p0, p1, p2, p3 = pts[i-1], pts[i], pts[i+1], pts[i+2]
        for s in range(sub):
            t = s/sub
            t2, t3 = t*t, t*t*t
            out.append(tuple(0.5*((2*p1[k])+(-p0[k]+p2[k])*t+(2*p0[k]-5*p1[k]+4*p2[k]-p3[k])*t2
                                  +(-p0[k]+3*p1[k]-3*p2[k]+p3[k])*t3) for k in range(3)))
    out.append(tuple(points[-1]))
    return out


def _tube(path, radius, sides=8):
    """Closed capped tube swept along a polyline (parallel-transport frames)."""
    n = len(path)
    tans = []
    for k in range(n):
        a = path[max(k-1, 0)]
        b = path[min(k+1, n-1)]
        tans.append(_norm(tuple(y-x for x, y in zip(a, b))))
    ref = (0.0, 0.0, 1.0) if abs(tans[0][2]) < 0.9 else (1.0, 0.0, 0.0)
    nrm = _norm(_cross(tans[0], ref))
    verts, faces = [], []
    for k in range(n):
        t = tans[k]
        if k:
            nrm = tuple(x-_dot(nrm, t)*y for x, y in zip(nrm, t))
            nrm = _norm(nrm)
        bn = _cross(t, nrm)
        for i in range(sides):
            ph = TAU*i/sides
            verts.append(tuple(path[k][c]+radius*(math.cos(ph)*nrm[c]+math.sin(ph)*bn[c])
                               for c in range(3)))
    for k in range(n-1):
        for i in range(sides):
            j = (i+1) % sides
            a, b, c, d = k*sides+i, k*sides+j, (k+1)*sides+j, (k+1)*sides+i
            faces.extend(((a, b, c), (a, c, d)))
    c0 = len(verts)
    verts.append(tuple(path[0]))
    c1 = len(verts)
    verts.append(tuple(path[-1]))
    for i in range(sides):
        j = (i+1) % sides
        faces.append((c0, j, i))
        faces.append((c1, (n-1)*sides+i, (n-1)*sides+j))
    return MeshData(tuple(verts), tuple(faces))


def _torus(center, axis, big, small, nu=14, nv=6):
    n = _norm(axis)
    ref = (0.0, 0.0, 1.0) if abs(n[2]) < 0.9 else (1.0, 0.0, 0.0)
    u = _norm(_cross(n, ref))
    v = _cross(n, u)
    verts, faces = [], []
    for i in range(nu):
        a = TAU*i/nu
        for j in range(nv):
            b = TAU*j/nv
            rad = big+small*math.cos(b)
            verts.append(tuple(center[k]+rad*(math.cos(a)*u[k]+math.sin(a)*v[k])+small*math.sin(b)*n[k]
                               for k in range(3)))
    for i in range(nu):
        for j in range(nv):
            a, b = i*nv+j, ((i+1) % nu)*nv+j
            c, d = ((i+1) % nu)*nv+(j+1) % nv, i*nv+(j+1) % nv
            faces.extend(((a, b, c), (a, c, d)))
    return MeshData(tuple(verts), tuple(faces))


def _bend_golgi(p, radius):
    a = p[0]/radius
    x = radius*math.sin(a)-p[2]*math.sin(a)
    zb = radius-radius*math.cos(a)+p[2]*math.cos(a)
    # rotate +90 deg about X: (x, y, z) -> (x, -z, y)
    return (x, -zb, p[1])


# ---------------------------------------------------------------- layout
def _layout():
    items, lab = [], {}

    def add(part, name, mesh, mat, smooth=True):
        items.append((part, name, mesh, mat, smooth))

    # --- cell envelope (membrana) and cytosol floor (citoplasma)
    SEG, RNG = 40, 14
    cell = CutawayProfile(radii=(0.15, 0.125, 0.125), cut_fraction=0.06,
                          wall_fraction=0.06, center=(0, 0, 0))
    add('membrana', 'envoltura abierta', cell.shell(segments=SEG, rings=RNG), 'membrana', False)
    fill = cell.fill(clearance=0.02, inset=0.04, segments=SEG, rings=RNG)
    add('citoplasma', 'citosol', fill, 'citoplasma', False)
    zf = max(v[2] for v in fill.vertices)
    th0 = math.acos(0.06)
    ph = math.radians(-50)
    lab['membrana'] = (0.97*0.15*math.sin(th0)*math.cos(ph), 0.97*0.125*math.sin(th0)*math.sin(ph), cell.cut_z)
    lab['citoplasma'] = (0.025, 0.05, zf+0.001)

    # --- nucleus with partial envelope, chromatin and nucleolus
    nc = (-0.010, 0.010, 0.026)
    nuc = CutawayProfile(radii=(0.046, 0.043, 0.040), cut_fraction=0.25,
                         wall_fraction=0.12, center=nc)
    add('nucleo', 'envoltura nuclear parcial', nuc.shell(segments=32, rings=12), 'nucleo', False)
    nfill = nuc.fill(clearance=0.03, inset=0.2, segments=32, rings=12)
    add('nucleo', 'cromatina', nfill, 'cromatina', False)
    nzf = max(v[2] for v in nfill.vertices)
    nth = math.acos(0.25)
    nph = math.radians(-60)
    lab['nucleo'] = (nc[0]+0.94*0.046*math.sin(nth)*math.cos(nph),
                     nc[1]+0.94*0.043*math.sin(nth)*math.sin(nph), nuc.cut_z)
    nol = (nc[0]+0.005, nc[1]-0.004, nzf-0.001)
    add('nucleolo', 'nucleolo', sphere((0.009,)*3, center=nol, segments=20, rings=10), 'nucleolo')
    lab['nucleolo'] = (nol[0], nol[1], nol[2]+0.009+0.001)
    # nuclear pores suggested as small rings on the outer envelope
    pores = []
    for th in (84, 96, 108, 120):
        for k in range(6):
            phd = -105+k*30+(th % 24)/2
            t, f = math.radians(th), math.radians(phd)
            d = (math.sin(t)*math.cos(f), math.sin(t)*math.sin(f), math.cos(t))
            ra = (0.046, 0.043, 0.040)
            p = tuple(nc[i]+ra[i]*d[i] for i in range(3))
            nrm = (d[0]/ra[0], d[1]/ra[1], d[2]/ra[2])
            nn = _norm(nrm)
            pores.append(_torus(tuple(p[i]+0.0004*nn[i] for i in range(3)), nn, 0.0028, 0.0010))
    add('nucleo', 'poros nucleares', _merge(pores), 'poros')

    # --- RER: flattened cisternae beside the nucleus, with anchored ribosomes
    rc = (-0.072, 0.015)
    rb = 0.0022
    beads = []
    rer_meshes = []
    specs = [(0.0, zf+0.002, 0.040), (0.0, zf+0.017, 0.038), (-0.032, zf+0.002, 0.036)]
    for k, (dx, zc, rx) in enumerate(specs):
        sheet = FlattenedCisterna(radii=(rx, 0.013, 0.004), wave=0.0015)

        def place(p, zc=zc, dx=dx):
            return (-p[1]+rc[0]+dx, p[0]+rc[1], p[2]+zc)
        rer_meshes.append(_tf(sheet.mesh(segments=24, rings=12), place))
        for j in (2, 3, 4, 5):
            for i in range(((j+k) % 2)*2, 24, 4):
                c, _n = sheet.anchor(math.pi*j/12, TAU*i/24, offset=rb)
                beads.append(sphere((rb,)*3, center=place(c), segments=8, rings=4))
        if k == 1:
            lab['rer'] = place(sheet.surface(math.pi/6, math.pi)[0])
    add('rer', 'cisternas rugosas', _merge(rer_meshes), 'rer')
    # free ribosomes
    for (x, y) in [(-0.050, 0.072), (-0.036, 0.080), (-0.024, 0.070), (0.060, -0.052),
                   (0.0, -0.047), (0.012, -0.033), (0.050, 0.018), (-0.030, -0.040),
                   (0.100, 0.022), (0.082, 0.010), (0.035, -0.040)]:
        beads.append(sphere((rb,)*3, center=(x, y, zf+0.0012), segments=8, rings=4))
    add('ribosomas', 'ribosomas', _merge(beads), 'ribosomas')
    lab['ribosomas'] = (-0.036, 0.080, zf+0.0012+rb+0.001)

    # --- REL: tubular network, no ribosomes
    zt = zf+0.0035
    rel_paths = [
        [(-0.097, -0.040), (-0.085, -0.046), (-0.070, -0.040), (-0.055, -0.055), (-0.040, -0.048), (-0.028, -0.058)],
        [(-0.070, -0.040), (-0.060, -0.031), (-0.048, -0.031), (-0.040, -0.022)],
        [(-0.055, -0.055), (-0.062, -0.068), (-0.048, -0.074)],
    ]
    rel = []
    for pth in rel_paths:
        sp = _spline([(x, y, zt) for x, y in pth], sub=6)
        rel.append(_tube(sp, 0.0035, sides=8))
    add('rel', 'red tubular', _merge(rel), 'rel')
    lab['rel'] = (-0.055, -0.055, zt+0.0035+0.001)

    # --- Golgi: curved stack of flattened cisternae, concave side towards nucleus
    gc = (0.082, 0.048)
    gang = math.radians(-65)
    gz = zf+0.0125
    bendR = 0.045

    def gplace(p):
        q = _bend_golgi(p, bendR)
        q = _rz(q, gang)
        return (q[0]+gc[0], q[1]+gc[1], q[2]+gz)
    gl = []
    for k in (-1.5, -0.5, 0.5, 1.5):
        sheet = FlattenedCisterna(radii=(0.026-0.002*abs(k), 0.012, 0.0028), wave=0.0)
        gl.append(_tf(sheet.mesh(segments=24, rings=10), lambda p, k=k: gplace((p[0], p[1], p[2]+k*0.0095))))
    add('golgi', 'pila curva', _merge(gl), 'golgi')
    rim = []
    for k in (-1.5, -0.5, 0.5, 1.5):
        for sg in (-1, 1):
            rim.append(sphere((0.0028,)*3, center=gplace((sg*(0.026-0.002*abs(k)), 0, k*0.0095)),
                              segments=10, rings=5))
    add('vesiculas', 'vesiculas de borde golgi', _merge(rim), 'vesiculas')
    lab['golgi'] = (gplace((0, 0, 0))[0], gplace((0, 0, 0))[1], gz+0.012+0.001)

    # --- vesicles around Golgi and a few elsewhere
    vr = 0.0045
    vs = []

    def gv(x, y):
        q = _rz((x, y, 0), gang)
        return (q[0]+gc[0], q[1]+gc[1], zf+0.0045)
    for (x, y) in [(-0.012, -0.031), (0.010, -0.035), (0.0, -0.045), (-0.034, -0.020),
                   (0.035, -0.022), (0.0, 0.022), (0.013, 0.025)]:
        vs.append(sphere((vr,)*3, center=gv(x, y), segments=12, rings=6))
    for (x, y) in [(0.040, 0.050), (-0.040, 0.050)]:
        vs.append(sphere((vr,)*3, center=(x, y, zf+0.0045), segments=12, rings=6))
    add('vesiculas', 'vesiculas', _merge(vs), 'vesiculas')
    c = gv(0.0, -0.045)
    lab['vesiculas'] = (c[0], c[1], c[2]+vr+0.001)

    # --- mitochondria: two open (cut) with cristae, one closed
    mo, mc, mcr = [], [], []
    mrad, mwall = (0.025, 0.011, 0.011), 0.22
    inner_rz = mrad[2]*(1-mwall)
    zc = zf+inner_rz+0.0003

    def mplace(p, x, y, a):
        q = _rz(p, math.radians(a))
        return (q[0]+x, q[1]+y, q[2]+zc)
    for (x, y, a) in [(0.090, -0.040, 30), (0.020, -0.066, -20)]:
        prof = CutawayProfile(radii=mrad, cut_fraction=0.15, wall_fraction=mwall, center=(0, 0, 0))
        mo.append(_tf(prof.shell(segments=24, rings=10), lambda p, x=x, y=y, a=a: mplace(p, x, y, a)))
        for x0 in (-0.012, -0.004, 0.004, 0.012):
            plate = sphere((0.0011, 0.0055, 0.0045), center=(x0, 0, -0.001), segments=12, rings=6)
            mcr.append(_tf(plate, lambda p, x=x, y=y, a=a: mplace(p, x, y, a)))
    s0 = sphere(mrad, segments=24, rings=10)
    x, y, a = 0.015, 0.088, 8
    mc.append(_tf(s0, lambda p: mplace(p, x, y, a)))
    add('mitocondrias', 'membrana externa', _merge(mo+mc), 'mitocondrias')
    add('mitocondrias', 'crestas', _merge(mcr), 'crestas')
    lab['mitocondrias'] = (0.090, -0.040, zc+0.0045+0.001)

    # --- lysosomes
    ly = []
    for (x, y) in [(0.114, 0.000), (0.050, -0.084), (-0.072, -0.082)]:
        ly.append(sphere((0.009,)*3, center=(x, y, zf+0.005), segments=16, rings=8))
    add('lisosomas', 'lisosomas', _merge(ly), 'lisosomas')
    lab['lisosomas'] = (0.050, -0.084, zf+0.005+0.009+0.001)

    # --- centrosome: two roughly perpendicular centrioles near the nucleus
    zcn = zf+0.0065
    ca = _tube([(0.046, 0.0, zcn), (0.055, 0.0, zcn), (0.064, 0.0, zcn)], 0.005, sides=10)
    cb = _tube([(0.055, -0.0255, zcn), (0.055, -0.0165, zcn), (0.055, -0.0075, zcn)], 0.005, sides=10)
    add('centrosoma', 'centriolos', _merge([ca, cb]), 'centrosoma')
    bands = []
    for off in (-0.006, 0.0, 0.006):
        bands.append(_torus((0.055+off, 0.0, zcn), (1, 0, 0), 0.0052, 0.0008, nu=14, nv=5))
        bands.append(_torus((0.055, -0.0165+off, zcn), (0, 1, 0), 0.0052, 0.0008, nu=14, nv=5))
    add('centrosoma', 'bandas de tripletes', _merge(bands), 'banda')
    lab['centrosoma'] = (0.055, 0.0, zcn+0.005+0.001)

    # --- sparse cytoskeleton (cortical filaments, not radial from the centrosome)
    zk = zf+0.0018
    fil_paths = [
        [(-0.075, 0.084), (-0.050, 0.096), (-0.020, 0.100)],
        [(-0.035, -0.092), (-0.005, -0.099), (0.020, -0.095), (0.034, -0.099)],
        [(0.120, 0.012), (0.119, 0.024), (0.114, 0.034)],
    ]
    fl = [_tube(_spline([(x, y, zk) for x, y in p], sub=6), 0.0016, sides=6) for p in fil_paths]
    add('citoesqueleto', 'filamentos', _merge(fl), 'citoesqueleto')
    lab['citoesqueleto'] = (-0.005, -0.099, zk+0.0016+0.001)
    return items, lab


# ---------------------------------------------------------------- build
def build():
    items, labels = _layout()
    c, s = math.cos(TILT), math.sin(TILT)

    def rot(p):
        return (p[0], p[1]*c-p[2]*s, p[1]*s+p[2]*c)
    rotated = [(pt, nm, _tf(m, rot), mt, sm) for pt, nm, m, mt, sm in items]
    allv = [v for _, _, m, _, _ in rotated for v in m.vertices]
    lo = [min(v[k] for v in allv) for k in range(3)]
    hi = [max(v[k] for v in allv) for k in range(3)]
    mid = [(a+b)/2 for a, b in zip(lo, hi)]
    scale = 0.30/max(b-a for a, b in zip(lo, hi))

    def fin(p):
        return tuple((p[k]-mid[k])*scale for k in range(3))
    mats = {k: material('Celula · '+k, col, roughness=r) for k, (col, r) in MATS.items()}
    for part, name, mesh, mat, smooth in rotated:
        mesh_object(name, part, _tf(mesh, fin), mats[mat], smooth=smooth, max_triangles=45000)
    parts = {}
    for pid, p in labels.items():
        parts[pid] = {'label_position': [round(x, 6) for x in fin(rot(p))]}
    return {
        'title': 'Célula animal · detalle v1 (corte abierto)',
        'design_notes': [
            'Detalle: poros nucleares, mitocondrias abiertas con crestas, bandas de centríolos, vesículas de borde del Golgi.',
            'Envoltura elipsoidal abierta por un corte inclinado 42 grados hacia arriba y el frente (-Y).',
            'Citosol como suelo pálido contenido; orgánulos sobre y parcialmente dentro de él.',
            'Núcleo con envoltura parcial, cromatina y nucléolo visible; RER a su lado, Golgi más lejos.',
            'Escala de maqueta: dimensión mayor 0.30 m medida sobre vértices reales.',
        ],
        'parts': parts,
    }
