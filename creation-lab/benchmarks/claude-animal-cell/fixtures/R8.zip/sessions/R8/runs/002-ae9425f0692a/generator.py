"""R8 · detalle v1 · célula animal educativa de corte abierto.

Deriva de blockout-v1.py (aprobado). Mismo marco y misma disposición: todo se
compone con el corte horizontal y el citosol como suelo plano en z = FLOOR_Z;
al final se inclina 30° alrededor de X (abertura arriba y hacia -Y), se centra
y se escala con los vértices reales a 0.30 m. Sin E/S, luces ni cámaras.

Detalle añadido: membrana suave y de mayor resolución; poros en la envoltura
nuclear abierta (cara externa e interna) y nucléolo lobulado; cisternas del
RER con ribosomas en anclajes de rejilla de la biblioteca y ribosomas libres;
REL tubular curvo sin ribosomas; Golgi curvo con vesículas en gemación; una
mitocondria abierta con crestas interiores; centríolos de 9 túbulos
perpendiculares; citoesqueleto escaso, más grueso y oscuro.
"""
import math
import random

from components import (CutawayProfile, FlattenedCisterna, MeshData, material,
                        mesh_object, sphere)

TARGET = 0.30
TILT = math.radians(30.0)          # abertura hacia arriba y hacia -Y
CELL_RADII = (0.150, 0.125, 0.105)  # nominal; se reescala con vértices reales
CELL_WALL = 0.05
CELL_CUT = 0.12
FLOOR_Z = -0.030                    # cara superior del citosol (marco local)
NUC = (-0.035, 0.020)               # centro del núcleo en planta
NUC_RADII = (0.046, 0.044, 0.040)
NUC_Z = -0.015
CENTRO = (-0.009, 0.076)


# --------------------------------------------------------------------------
# Utilidades geométricas puras (sin bpy)
# --------------------------------------------------------------------------

def _map(mesh, fn):
    return MeshData(tuple(fn(v) for v in mesh.vertices), mesh.faces)


def _merge(meshes):
    vertices, faces = [], []
    for mesh in meshes:
        base = len(vertices)
        vertices.extend(mesh.vertices)
        faces.extend(tuple(base+i for i in face) for face in mesh.faces)
    return MeshData(tuple(vertices), tuple(faces))


def _rot_z(point, angle, center):
    c, s = math.cos(angle), math.sin(angle)
    x, y = point[0]-center[0], point[1]-center[1]
    return (center[0]+c*x-s*y, center[1]+s*x+c*y, point[2])


def _norm(v):
    length = math.sqrt(sum(x*x for x in v))
    return tuple(x/length for x in v)


def _cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def _dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def _signed_volume(vertices, faces):
    o = vertices[0]
    total = 0.0
    for f in faces:
        a, b, c = [tuple(vertices[i][k]-o[k] for k in range(3)) for i in f]
        total += _dot(a, _cross(b, c))/6
    return total


def _tube(points, radius, sides=8):
    """Tubo cerrado a lo largo de una polilínea, tapas con un vértice central."""
    n = len(points)
    tangents = []
    for k in range(n):
        a, b = points[max(k-1, 0)], points[min(k+1, n-1)]
        tangents.append(_norm(tuple(q-p for p, q in zip(a, b))))
    ref = (0.0, 0.0, 1.0) if abs(tangents[0][2]) < 0.9 else (1.0, 0.0, 0.0)
    normal = _norm(_cross(tangents[0], ref))
    vertices = [tuple(points[0])]
    for k in range(n):
        t = tangents[k]
        normal = _norm(tuple(nv-_dot(normal, t)*tv for nv, tv in zip(normal, t)))
        binormal = _cross(t, normal)
        for i in range(sides):
            ang = math.tau*i/sides
            vertices.append(tuple(points[k][d]+radius*(math.cos(ang)*normal[d]+math.sin(ang)*binormal[d])
                                  for d in range(3)))
    vertices.append(tuple(points[-1]))
    end = len(vertices)-1
    faces = []
    for i in range(sides):
        faces.append((0, 1+i, 1+(i+1) % sides))
    for k in range(n-1):
        a, b = 1+k*sides, 1+(k+1)*sides
        for i in range(sides):
            nxt = (i+1) % sides
            faces.extend(((a+i, b+i, b+nxt), (a+i, b+nxt, a+nxt)))
    last = 1+(n-1)*sides
    for i in range(sides):
        faces.append((end, last+(i+1) % sides, last+i))
    if _signed_volume(vertices, faces) < 0:
        faces = [tuple(reversed(f)) for f in faces]
    return MeshData(tuple(vertices), tuple(faces))


def _wrap(center, base_angle, rd, z0):
    """(u, v, w) de una cisterna -> arco alrededor de center.

    u = longitud de arco (tangente), v = vertical, w = radial (grosor).
    Jacobiano positivo: conserva el winding exterior.
    """
    def fn(p):
        u, v, w = p
        phi = base_angle+u/rd
        r = rd+w
        return (center[0]+r*math.cos(phi), center[1]+r*math.sin(phi), z0+v)
    return fn


def _frame(origin, normal):
    """Mapa (u, v, w) -> origin + u*t1 + v*t2 + w*n con t1 x t2 = n."""
    n = _norm(normal)
    ref = (0.0, 0.0, 1.0) if abs(n[2]) < 0.95 else (1.0, 0.0, 0.0)
    t1 = _norm(_cross(ref, n))
    t2 = _cross(n, t1)
    def fn(p):
        return tuple(origin[d]+p[0]*t1[d]+p[1]*t2[d]+p[2]*n[d] for d in range(3))
    return fn


def _dir(angle_deg, dist, origin):
    a = math.radians(angle_deg)
    return (origin[0]+dist*math.cos(a), origin[1]+dist*math.sin(a))


def _ellipsoid_point(center, radii, theta, phi):
    p = (radii[0]*math.sin(theta)*math.cos(phi), radii[1]*math.sin(theta)*math.sin(phi),
         radii[2]*math.cos(theta))
    n = (p[0]/radii[0]**2, p[1]/radii[1]**2, p[2]/radii[2]**2)
    return tuple(c+x for c, x in zip(center, p)), _norm(n)


# --------------------------------------------------------------------------
# Composición en el marco local
# --------------------------------------------------------------------------

def _scene():
    items = []    # (nombre, part_id, MeshData, clave material, smooth)
    labels = {}
    occupied = []  # círculos en planta (x, y, r) para ribosomas libres

    # Membrana: envoltura con labio continuo, más resolución y sombreado suave.
    cell = CutawayProfile(radii=CELL_RADII, cut_fraction=CELL_CUT,
                          wall_fraction=CELL_WALL, center=(0, 0, 0))
    items.append(('envoltura abierta', 'membrana', cell.shell(segments=80, rings=24),
                  'membrana', True))
    a_lab = math.radians(-150)
    s_cut = math.sqrt(1-CELL_CUT**2)
    rim_r = 0.5*(1+(1-CELL_WALL))
    labels['membrana'] = (CELL_RADII[0]*s_cut*rim_r*math.cos(a_lab),
                          CELL_RADII[1]*s_cut*rim_r*math.sin(a_lab), cell.cut_z+0.002)

    # Citoplasma: suelo pálido (citosol) bajo los orgánulos.
    inner = cell.inner_radii
    cyt_wall = 0.01
    cyt_radii = tuple(r*0.995/(1-cyt_wall) for r in inner)
    cyt = CutawayProfile(radii=cyt_radii, cut_fraction=FLOOR_Z/cyt_radii[2],
                         wall_fraction=cyt_wall, center=(0, 0, 0))
    items.append(('citosol', 'citoplasma',
                  cyt.fill(clearance=0.004, inset=0.002, segments=80, rings=12),
                  'citoplasma', False))
    floor_top = cyt.cut_z-0.002*cyt_radii[2]
    cyto_label = (0.068, -0.010)
    labels['citoplasma'] = (cyto_label[0], cyto_label[1], floor_top+0.001)

    # Núcleo: envoltura abierta (parcial) con poros + nucleoplasma.
    nuc_center = (NUC[0], NUC[1], NUC_Z)
    nuc = CutawayProfile(radii=NUC_RADII, cut_fraction=0.30, wall_fraction=0.12,
                         center=nuc_center)
    items.append(('envoltura nuclear', 'nucleo', nuc.shell(segments=48, rings=16),
                  'nucleo', False))
    np_inset = 0.15
    items.append(('nucleoplasma', 'nucleo',
                  nuc.fill(clearance=0.03, inset=np_inset, segments=48, rings=16),
                  'nucleoplasma', True))
    nucleoplasm_top = nuc.cut_z-np_inset*NUC_RADII[2]
    occupied.append((NUC[0], NUC[1], NUC_RADII[0]+0.004))
    pores = []
    pore = sphere((0.0030, 0.0030, 0.0011), segments=8, rings=4)
    # Cara externa: bandas visibles entre el suelo y el borde del corte.
    for row, theta_deg in enumerate((80.0, 93.0)):
        for k in range(14):
            phi = math.radians(k*360/14+row*360/28)
            p, n = _ellipsoid_point(nuc_center, NUC_RADII, math.radians(theta_deg), phi)
            if p[2] < FLOOR_Z+0.004:
                continue
            pores.append(_map(pore, _frame(tuple(p[d]+0.0002*n[d] for d in range(3)), n)))
    # Cara interna: banda entre el nucleoplasma y el borde.
    nin = nuc.inner_radii
    z_band = 0.5*(nucleoplasm_top+nuc.cut_z)
    theta_in = math.acos((z_band-NUC_Z)/nin[2])
    for k in range(12):
        phi = math.radians(k*30+15)
        p, n = _ellipsoid_point(nuc_center, nin, theta_in, phi)
        inward = tuple(-x for x in n)
        pores.append(_map(pore, _frame(tuple(p[d]+0.0002*inward[d] for d in range(3)), inward)))
    items.append(('poros nucleares', 'nucleo', _merge(pores), 'poros', True))
    labels['nucleo'] = (NUC[0]-NUC_RADII[0]*0.93, NUC[1]-0.008, nuc.cut_z+0.002)

    # Nucléolo: masa lobulada sin membrana, apoyada en el nucleoplasma.
    nl_r = 0.0140
    nl_c = (NUC[0]+0.006, NUC[1]+0.004, nucleoplasm_top+0.003)
    lobes = [sphere((nl_r, nl_r*0.95, nl_r*0.85), center=nl_c, segments=28, rings=14),
             sphere((0.0075,)*3, center=(nl_c[0]+0.010, nl_c[1]-0.005, nl_c[2]+0.001), segments=16, rings=8),
             sphere((0.0065,)*3, center=(nl_c[0]-0.008, nl_c[1]+0.008, nl_c[2]+0.002), segments=16, rings=8)]
    items.append(('nucleolo', 'nucleolo', _merge(lobes), 'nucleolo', True))
    labels['nucleolo'] = (nl_c[0], nl_c[1], nl_c[2]+nl_r*0.85+0.002)

    # RER: tres cisternas aplanadas curvas junto al núcleo; ribosomas en anclajes.
    rer_meshes, ribo_bound = [], []
    rer_base, rer_half = -60.0, 0.85
    rer_b, rer_c = 0.011, 0.0022
    rer_z = FLOOR_Z+0.008
    ribo_r = 0.0015
    seg_rer, rings_rer = 40, 12
    for rd in (0.055, 0.0645, 0.074):
        sheet = FlattenedCisterna(radii=(rd*rer_half, rer_b, rer_c), wave=0.0006,
                                  center=(0, 0, 0))
        fn = _wrap(NUC, math.radians(rer_base), rd, rer_z)
        rer_meshes.append(_map(sheet.mesh(segments=seg_rer, rings=rings_rer), fn))
        # Anclajes de rejilla (theta=pi*j/rings, phi=tau*i/segments): tocan la malla.
        for j in (3, 4, 5):
            for i in range(1+j % 2, seg_rer, 4):
                pos, _n = sheet.anchor(math.pi*j/rings_rer, math.tau*i/seg_rer, offset=ribo_r)
                ribo_bound.append(sphere((ribo_r,)*3, center=fn(pos), segments=8, rings=5))
        for ang in range(-105, -10, 10):
            p = _dir(ang, rd, NUC)
            occupied.append((p[0], p[1], 0.006))
    items.append(('cisternas rugosas', 'rer', _merge(rer_meshes), 'rer', True))
    lab = _dir(rer_base, 0.074+rer_c, NUC)
    labels['rer'] = (lab[0], lab[1], rer_z+rer_b+0.002)

    # REL: túbulos lisos y curvos a continuación del RER, sin ribosomas.
    main = []
    steps = 16
    for k in range(steps+1):
        ang = -115-61*k/steps
        r = 0.068+0.0055*math.sin(k*0.95)
        p = _dir(ang, r, NUC)
        main.append((p[0], p[1], FLOOR_Z+0.0055+0.0015*math.sin(k*0.7)))
    branch = [main[4]]
    for k in range(1, 6):
        ang = -128+3.0*k
        p = _dir(ang, 0.071+0.0035*k, NUC)
        branch.append((p[0], p[1], FLOOR_Z+0.005+0.0008*k))
    branch2 = [main[11]]
    for k in range(1, 5):
        ang = -158-2.5*k
        p = _dir(ang, 0.071-0.0032*k, NUC)
        branch2.append((p[0], p[1], FLOOR_Z+0.0055+0.0006*k))
    rel_paths = [main, branch, branch2]
    items.append(('tubulos lisos', 'rel', _merge([_tube(p, 0.0032, 10) for p in rel_paths]),
                  'rel', True))
    for path in rel_paths:
        for p in path:
            occupied.append((p[0], p[1], 0.006))
    labels['rel'] = (main[8][0], main[8][1], main[8][2]+0.0032+0.002)

    # Golgi: pila de 4 cisternas curvas y aplanadas, más alejada que el RER.
    g_center = _dir(20.0, 0.070, NUC)
    golgi = []
    g_b, g_c = 0.008, 0.0017
    g_z = FLOOR_Z+0.007
    for k, rho in enumerate((0.022, 0.028, 0.034, 0.040)):
        sheet = FlattenedCisterna(radii=(rho*(1.02-0.04*k), g_b-0.0004*k, g_c), wave=0.0005,
                                  center=(0, 0, 0))
        golgi.append(_map(sheet.mesh(segments=32, rings=10),
                          _wrap(g_center, math.radians(20.0), rho, g_z)))
        for ang in range(-35, 80, 12):
            p = _dir(ang, rho, g_center)
            occupied.append((p[0], p[1], 0.005))
    items.append(('pila de cisternas', 'golgi', _merge(golgi), 'golgi', True))
    lab = _dir(20.0, 0.040+g_c, g_center)
    labels['golgi'] = (lab[0], lab[1], g_z+g_b+0.002)

    # Vesículas: cara trans del Golgi, gemación en los extremos y hacia la membrana.
    ves = []
    ves_spec = [(_dir(a, 0.050, g_center), 0.0045) for a in (0, 25, 50)]
    ves_spec += [(_dir(-44, 0.025, g_center), 0.0033), (_dir(84, 0.037, g_center), 0.0033),
                 ((0.115, 0.035), 0.0045), ((-0.038, -0.096), 0.0042)]
    for (x, y), r in ves_spec:
        ves.append(sphere((r,)*3, center=(x, y, FLOOR_Z+0.004), segments=14, rings=8))
        occupied.append((x, y, r+0.003))
    items.append(('vesiculas', 'vesiculas', _merge(ves), 'vesiculas', True))
    labels['vesiculas'] = (ves_spec[0][0][0], ves_spec[0][0][1], FLOOR_Z+0.004+0.0045+0.002)

    # Mitocondrias: tres cerradas y una abierta con crestas interiores.
    mito_r = (0.017, 0.0075, 0.0075)
    mz = FLOOR_Z+0.004
    closed = []
    for (x, y), yaw in [((0.055, -0.062), 30), ((-0.065, -0.080), 20),
                        ((-0.060, 0.085), 160), ((0.105, 0.000), 90)]:
        m = sphere(mito_r, center=(x, y, mz), segments=20, rings=10)
        closed.append(_map(m, lambda p, yaw=yaw, x=x, y=y: _rot_z(p, math.radians(yaw), (x, y))))
        for t in (-0.011, 0.0, 0.011):
            occupied.append((x+t*math.cos(math.radians(yaw)), y+t*math.sin(math.radians(yaw)), 0.010))
    items.append(('mitocondrias cerradas', 'mitocondrias', _merge(closed), 'mitocondrias', True))

    om_xy, om_yaw = (-0.005, -0.077), math.radians(4.0)
    om_radii = (0.022, 0.0095, 0.0090)
    om_z = FLOOR_Z+0.0092
    om = CutawayProfile(radii=om_radii, cut_fraction=0.18, wall_fraction=0.14, center=(0, 0, 0))
    def om_place(p):
        c, s = math.cos(om_yaw), math.sin(om_yaw)
        return (om_xy[0]+c*p[0]-s*p[1], om_xy[1]+s*p[0]+c*p[1], om_z+p[2])
    items.append(('mitocondria abierta', 'mitocondrias',
                  _map(om.shell(segments=32, rings=10), om_place), 'mitocondrias', True))
    # Crestas: láminas aplanadas transversales, alternando desde cada pared.
    oin = om.inner_radii
    cristae = []
    xs = (-0.0125, -0.0075, -0.0025, 0.0025, 0.0075, 0.0125)
    for k, x in enumerate(xs):
        f = math.sqrt(max(0.0, 1-(x/oin[0])**2))
        half_y, half_z = oin[1]*f, oin[2]*f
        side = 1 if k % 2 == 0 else -1
        ru, rv = half_y*0.62, min(half_z*0.48, (om.cut_z+half_z)*0.5*0.85)
        cz = 0.5*(om.cut_z-half_z*0.8)-0.0004
        plate = FlattenedCisterna(radii=(ru, rv, 0.00055), wave=0.0, center=(0, 0, 0))
        pm = plate.mesh(segments=16, rings=8)
        cy = side*(half_y-ru)*0.92
        # (u, v, w) -> (x = w, y = u, z = v): determinante positivo.
        cristae.append(_map(pm, lambda p, x=x, cy=cy, cz=cz: om_place((x+p[2], cy+p[0], cz+p[1]))))
    items.append(('crestas', 'mitocondrias', _merge(cristae), 'crestas', True))
    occupied.append((om_xy[0], om_xy[1], 0.012))
    occupied.append((om_xy[0]-0.014, om_xy[1], 0.010))
    occupied.append((om_xy[0]+0.014, om_xy[1], 0.010))
    labels['mitocondrias'] = (om_xy[0]+0.004, om_xy[1]-om_radii[1]*0.93, om_z+om.cut_z+0.002)

    # Lisosomas: tres esferas pequeñas.
    lys_r = 0.0065
    lys_xy = [(0.033, -0.087), (0.092, -0.042), (-0.105, 0.045)]
    lys = []
    for x, y in lys_xy:
        lys.append(sphere((lys_r,)*3, center=(x, y, FLOOR_Z+0.005), segments=16, rings=8))
        occupied.append((x, y, lys_r+0.003))
    items.append(('lisosomas', 'lisosomas', _merge(lys), 'lisosomas', True))
    labels['lisosomas'] = (lys_xy[1][0], lys_xy[1][1], FLOOR_Z+0.005+lys_r+0.002)

    # Centrosoma: dos centríolos perpendiculares de 9 túbulos cada uno.
    c_ring, c_rod, c_half = 0.0036, 0.0010, 0.0080
    cz = FLOOR_Z+0.0095
    rods = []
    for i in range(9):
        a = math.tau*i/9
        dy, dz = c_ring*math.cos(a), c_ring*math.sin(a)
        rods.append(_tube([(CENTRO[0]-c_half, CENTRO[1]+dy, cz+dz),
                           (CENTRO[0]+c_half, CENTRO[1]+dy, cz+dz)], c_rod, 6))
    c2x = CENTRO[0]+c_half+0.0065
    for i in range(9):
        a = math.tau*i/9
        dx, dy = c_ring*math.cos(a), c_ring*math.sin(a)
        rods.append(_tube([(c2x+dx, CENTRO[1]+dy, cz-c_half+0.0015),
                           (c2x+dx, CENTRO[1]+dy, cz+c_half+0.0015)], c_rod, 6))
    items.append(('centriolos', 'centrosoma', _merge(rods), 'centrosoma', True))
    occupied.append((CENTRO[0]+0.003, CENTRO[1], 0.017))
    labels['centrosoma'] = (c2x, CENTRO[1], cz+c_half+0.0015+0.003)

    # Citoesqueleto: escaso. Tres haces corticales, dos microtúbulos cortos
    # desde el centrosoma y un filamento por el interior del suelo.
    fil_r = 0.0017
    def arc(a0, a1, scale, steps=12):
        pts = []
        for k in range(steps+1):
            a = math.radians(a0+(a1-a0)*k/steps)
            pts.append((scale*0.136*math.cos(a), scale*0.113*math.sin(a),
                        FLOOR_Z+0.0020+0.0008*math.sin(3*a)))
        return pts
    fil = [arc(-100, -40, 0.93), arc(50, 105, 0.93), arc(-35, 10, 0.93), arc(165, 215, 0.93)]
    mt1 = [(CENTRO[0]+0.004, CENTRO[1]-0.005, FLOOR_Z+0.004), (0.010, 0.060, FLOOR_Z+0.0035),
           (0.022, 0.044, FLOOR_Z+0.0028), (0.030, 0.030, FLOOR_Z+0.0022)]
    mt2 = [(CENTRO[0]-0.006, CENTRO[1]-0.002, FLOOR_Z+0.004), (-0.022, 0.0745, FLOOR_Z+0.003),
           (-0.034, 0.0715, FLOOR_Z+0.0022)]
    inner_fil = [(0.050, -0.030, FLOOR_Z+0.0018), (0.062, -0.031, FLOOR_Z+0.0022),
                 (0.075, -0.029, FLOOR_Z+0.0018), (0.088, -0.022, FLOOR_Z+0.0022),
                 (0.098, -0.016, FLOOR_Z+0.0018), (0.112, -0.020, FLOOR_Z+0.0020)]
    fil += [mt1, mt2, inner_fil]
    items.append(('filamentos', 'citoesqueleto', _merge([_tube(p, fil_r, 8) for p in fil]),
                  'citoesqueleto', True))
    for path in fil:
        for p in path:
            occupied.append((p[0], p[1], 0.003))
    labels['citoesqueleto'] = (fil[2][6][0], fil[2][6][1], fil[2][6][2]+0.004)

    # Ribosomas libres (semilla del brief puesta por el worker) + adheridos.
    free = []
    tries = 0
    while len(free) < 30 and tries < 6000:
        tries += 1
        a = random.uniform(0, math.tau)
        rr = math.sqrt(random.uniform(0, 1))*0.86
        x, y = rr*0.136*math.cos(a), rr*0.113*math.sin(a)
        if any((x-ox)**2+(y-oy)**2 < (orad+0.003)**2 for ox, oy, orad in occupied):
            continue
        if any((x-fx)**2+(y-fy)**2 < 0.007**2 for fx, fy, _ in free):
            continue
        if (x-cyto_label[0])**2+(y-cyto_label[1])**2 < 0.010**2:
            continue
        free.append((x, y, FLOOR_Z+0.0008))
    ribos = ribo_bound+[sphere((ribo_r,)*3, center=c, segments=8, rings=5) for c in free]
    items.append(('ribosomas', 'ribosomas', _merge(ribos), 'ribosomas', True))
    pick = ribo_bound[len(ribo_bound)-len(ribo_bound)//6].vertices[0]
    labels['ribosomas'] = (pick[0], pick[1], pick[2]+0.002)
    return items, labels


# --------------------------------------------------------------------------
# Transformación global: inclinación, centrado y escala por vértices reales
# --------------------------------------------------------------------------

def _tilt(p):
    c, s = math.cos(TILT), math.sin(TILT)
    return (p[0], p[1]*c-p[2]*s, p[1]*s+p[2]*c)


def _final():
    items, labels = _scene()
    tilted = [(n, pid, _map(m, _tilt), mk, sm) for n, pid, m, mk, sm in items]
    lo = [min(v[k] for _, _, m, _, _ in tilted for v in m.vertices) for k in range(3)]
    hi = [max(v[k] for _, _, m, _, _ in tilted for v in m.vertices) for k in range(3)]
    mid = [(a+b)/2 for a, b in zip(lo, hi)]
    scale = TARGET/max(b-a for a, b in zip(lo, hi))
    def fn(p):
        return tuple((p[k]-mid[k])*scale for k in range(3))
    final = [(n, pid, _map(m, fn), mk, sm) for n, pid, m, mk, sm in tilted]
    final_labels = {k: [round(x, 6) for x in fn(_tilt(v))] for k, v in labels.items()}
    return final, final_labels, scale


MATERIALS = {
    'membrana': ('Membrana plasmática', (0.88, 0.52, 0.42), 0.55),
    'citoplasma': ('Citosol', (0.80, 0.90, 0.86), 0.75),
    'nucleo': ('Envoltura nuclear', (0.36, 0.22, 0.62), 0.5),
    'poros': ('Poros nucleares', (0.12, 0.06, 0.26), 0.5),
    'nucleoplasma': ('Nucleoplasma', (0.62, 0.52, 0.82), 0.7),
    'nucleolo': ('Nucléolo', (0.16, 0.05, 0.30), 0.5),
    'rer': ('Retículo rugoso', (0.18, 0.38, 0.82), 0.5),
    'ribosomas': ('Ribosomas', (0.04, 0.04, 0.09), 0.5),
    'rel': ('Retículo liso', (0.32, 0.70, 0.28), 0.5),
    'golgi': ('Aparato de Golgi', (0.98, 0.76, 0.06), 0.45),
    'mitocondrias': ('Mitocondrias', (0.72, 0.06, 0.07), 0.5),
    'crestas': ('Crestas mitocondriales', (0.98, 0.62, 0.50), 0.55),
    'lisosomas': ('Lisosomas', (0.62, 0.10, 0.40), 0.5),
    'vesiculas': ('Vesículas', (0.25, 0.75, 0.85), 0.4),
    'centrosoma': ('Centríolos', (0.03, 0.36, 0.42), 0.5),
    'citoesqueleto': ('Citoesqueleto', (0.20, 0.22, 0.30), 0.6),
}


def build():
    final, labels, scale = _final()
    mats = {k: material(name, color, roughness=rough) for k, (name, color, rough) in MATERIALS.items()}
    for name, part_id, mesh, mat_key, smooth in final:
        mesh_object(name, part_id, mesh, mats[mat_key], smooth=smooth)
    return {
        'title': 'Célula animal · corte abierto (detalle R8 v1)',
        'design_notes': [
            'Envoltura elipsoidal con corte inclinado 30° hacia -Y: abre por arriba y hacia el frente; sombreado suave.',
            'El citosol es un suelo pálido plano; los orgánulos descansan parcialmente sobre él.',
            'Núcleo con envoltura abierta (parcial), poros sugeridos en cara externa e interna, nucleoplasma y nucléolo lobulado sin membrana.',
            'RER: cisternas aplanadas curvas junto al núcleo con ribosomas en anclajes de superficie; ribosomas libres en el citosol.',
            'REL: túbulos curvos ramificados sin ribosomas, en continuidad con el RER.',
            'Golgi: pila curva de cisternas aplanadas, más lejos que el RER, con vesículas en gemación y en tránsito.',
            'Una mitocondria abierta muestra crestas interiores; tres cerradas. Rojo de mitocondria separado del dorado del Golgi.',
            'Centrosoma: dos centríolos de 9 túbulos, perpendiculares, junto al núcleo. Citoesqueleto escaso y más legible.',
            f'Escala por vértices reales: dimensión mayor {TARGET} m (factor {scale:.4f}).',
        ],
        'parts': {k: {'label_position': v} for k, v in labels.items()},
    }
