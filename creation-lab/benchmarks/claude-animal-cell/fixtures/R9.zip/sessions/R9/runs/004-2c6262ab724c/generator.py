"""Animal cell detail (R9, detail v1). Cutaway bowl tilted toward the common camera.

Geometry is authored in a local bowl frame (opening toward +Z), then the whole
cell is tilted about X so the opening faces up and to the front (-Y), scaled so
the longest real-vertex dimension is exactly 0.300 m and centred on its bbox.
"""
import math
from components import (CutawayProfile, FlattenedCisterna, MeshData, sphere,
                        material, mesh_object, validate_mesh)

TILT_DEG = 35.0
SHELL_R = (0.160, 0.130, 0.135)
WALL = 0.07
CUT = 0.30
SEG, RINGS = 40, 14


# ---------- small helpers (pure python) ----------
def _rot(rx=0.0, ry=0.0, rz=0.0):
    a, b, c = map(math.radians, (rx, ry, rz))
    ca, sa, cb, sb, cc, sc = math.cos(a), math.sin(a), math.cos(b), math.sin(b), math.cos(c), math.sin(c)
    # R = Rz @ Ry @ Rx
    return ((cc*cb, cc*sb*sa-sc*ca, cc*sb*ca+sc*sa),
            (sc*cb, sc*sb*sa+cc*ca, sc*sb*ca-cc*sa),
            (-sb, cb*sa, cb*ca))


def _apply(R, p):
    return tuple(R[i][0]*p[0]+R[i][1]*p[1]+R[i][2]*p[2] for i in range(3))


def place(mesh, rot=(0, 0, 0), t=(0, 0, 0)):
    R = _rot(*rot)
    return MeshData(tuple(tuple(a+b for a, b in zip(_apply(R, v), t)) for v in mesh.vertices), mesh.faces)


def place_pt(p, rot=(0, 0, 0), t=(0, 0, 0)):
    return tuple(a+b for a, b in zip(_apply(_rot(*rot), p), t))


def merge(meshes):
    verts, faces = [], []
    for m in meshes:
        o = len(verts)
        verts.extend(m.vertices)
        faces.extend(tuple(i+o for i in f) for f in m.faces)
    return MeshData(tuple(verts), tuple(faces))


def blob(radii, center, rot=(0, 0, 0), seg=14, rings=8):
    return place(sphere(radii, segments=seg, rings=rings), rot, center)


def _on_shell(phi_deg, z):
    s = math.sqrt(1-(z/SHELL_R[2])**2)
    p = math.radians(phi_deg)
    return (SHELL_R[0]*s*math.cos(p), SHELL_R[1]*s*math.sin(p), z)


def cyl(radius, length, seg=16, center=(0, 0, 0), rot=(0, 0, 0)):
    verts, faces = [], []
    for x in (-length/2, length/2):
        for i in range(seg):
            a = math.tau*i/seg
            verts.append((x, radius*math.cos(a), radius*math.sin(a)))
    verts += [(-length/2, 0, 0), (length/2, 0, 0)]
    c0, c1 = 2*seg, 2*seg+1
    for i in range(seg):
        n = (i+1) % seg
        faces += [(i, n, seg+n), (i, seg+n, seg+i), (c0, n, i), (c1, seg+i, seg+n)]
    return place(MeshData(tuple(verts), tuple(faces)), rot, center)


def _vol(m):
    o = m.vertices[0]
    v = 0.0
    for f in m.faces:
        a, b, c = [tuple(x-y for x, y in zip(m.vertices[i], o)) for i in f]
        v += (a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6
    return v


def fix_winding(m):
    if _vol(m) >= 0:
        return m
    return MeshData(m.vertices, tuple((f[0], f[2], f[1]) for f in m.faces))


def _norm(v):
    l = math.sqrt(sum(x*x for x in v))
    return tuple(x/l for x in v)


def _cross3(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def tube(path, radius, seg=8):
    """Closed tube along a polyline, with end caps."""
    n = len(path)
    verts, faces = [], []
    for i in range(n):
        a, b = path[max(i-1, 0)], path[min(i+1, n-1)]
        T = _norm(tuple(q-p for p, q in zip(a, b)))
        N = _cross3(T, (0, 0, 1))
        N = _norm(N) if sum(x*x for x in N) > 1e-9 else (1.0, 0.0, 0.0)
        B = _cross3(T, N)
        for k in range(seg):
            t = math.tau*k/seg
            verts.append(tuple(path[i][d]+radius*(math.cos(t)*N[d]+math.sin(t)*B[d]) for d in range(3)))
    for i in range(n-1):
        for k in range(seg):
            k1 = (k+1) % seg
            a0, a1, b0, b1 = i*seg+k, i*seg+k1, (i+1)*seg+k, (i+1)*seg+k1
            faces += [(a0, b0, b1), (a0, b1, a1)]
    c0 = len(verts); verts.append(path[0])
    c1 = len(verts); verts.append(path[-1])
    for k in range(seg):
        k1 = (k+1) % seg
        faces.append((c0, k, k1))
        faces.append((c1, (n-1)*seg+k1, (n-1)*seg+k))
    return fix_winding(MeshData(tuple(verts), tuple(faces)))


def torus(R, r, seg=12, tseg=6):
    verts, faces = [], []
    for i in range(seg):
        u = math.tau*i/seg
        for j in range(tseg):
            v = math.tau*j/tseg
            verts.append(((R+r*math.cos(v))*math.cos(u), (R+r*math.cos(v))*math.sin(u), r*math.sin(v)))
    for i in range(seg):
        for j in range(tseg):
            i1, j1 = (i+1) % seg, (j+1) % tseg
            a, b, c, d = i*tseg+j, i1*tseg+j, i1*tseg+j1, i*tseg+j1
            faces += [(a, b, c), (a, c, d)]
    return fix_winding(MeshData(tuple(verts), tuple(faces)))


def orient(mesh, n, t):
    """Rotate local +Z onto unit n, then translate by t."""
    n = _norm(n)
    ax = _cross3((0, 0, 1), n)
    s = math.sqrt(sum(x*x for x in ax))
    c = n[2]
    if s < 1e-9:
        R = ((1, 0, 0), (0, 1, 0), (0, 0, 1 if c > 0 else -1))
    else:
        k = tuple(x/s for x in ax)
        K = ((0, -k[2], k[1]), (k[2], 0, -k[0]), (-k[1], k[0], 0))
        R = tuple(tuple((1 if i == j else 0)+s*K[i][j]+(1-c)*sum(K[i][m]*K[m][j] for m in range(3))
                        for j in range(3)) for i in range(3))
    return MeshData(tuple(tuple(a+b for a, b in zip(_apply(R, v), t)) for v in mesh.vertices), mesh.faces)


def bend(mesh, k):
    return MeshData(tuple((x, y, z+k*x*x) for x, y, z in mesh.vertices), mesh.faces)


def ell_pt(c, r, phi_deg, relz):
    f = math.sqrt(1-(relz/r[2])**2)
    p = math.radians(phi_deg)
    return (c[0]+r[0]*f*math.cos(p), c[1]+r[1]*f*math.sin(p), c[2]+relz)


def centriole(rc, L, center, rotz):
    core = cyl(rc*0.86, L, 16)
    parts = [core]
    for i in range(9):
        a = math.tau*i/9
        parts.append(cyl(0.0014, L*1.02, 6, (0, rc*0.95*math.cos(a), rc*0.95*math.sin(a))))
    m = merge(parts)
    return place(m, (0, 0, rotz), center)


# ---------- local layout ----------
def _layout():
    prof = CutawayProfile(radii=SHELL_R, cut_fraction=CUT, wall_fraction=WALL)
    pieces, labels = [], {}
    pieces.append(("Envoltura", "membrana", prof.shell(segments=SEG, rings=RINGS), "membrana"))
    fill = prof.fill(clearance=0.03, inset=0.03, segments=SEG, rings=RINGS)
    pieces.append(("Citosol", "citoplasma", fill, "citoplasma"))
    zt = max(v[2] for v in fill.vertices)
    labels["membrana"] = _on_shell(-60, prof.cut_z-0.03)

    # nucleo elevado: envoltura parcial (ventana), poros, nucleoplasma y nucleolo grande
    nc = (0.0, 0.020, zt+0.004)
    nr = (0.054, 0.050, 0.040)
    nprof = CutawayProfile(radii=nr, cut_fraction=0.40, wall_fraction=0.08, center=nc)
    pieces.append(("Envoltura nuclear", "nucleo", nprof.shell(segments=36, rings=14), "nucleo"))
    pieces.append(("Nucleoplasma", "nucleo", nprof.fill(clearance=0.05, inset=0.35, segments=36, rings=14), "nucleoplasma"))
    pores = []
    for relz, phis in ((0.003, (-80, -45, -10, 25, 60, 95)), (0.011, (-62, -28, 8, 44, 78))):
        for ph in phis:
            p = ell_pt(nc, nr, ph, relz)
            a = math.radians(ph)
            f = math.sqrt(1-(relz/nr[2])**2)
            nrm = (f*math.cos(a)/nr[0], f*math.sin(a)/nr[1], relz/nr[2]**2*0+relz/(nr[2]**2))
            nrm = (math.cos(a)*f/nr[0], math.sin(a)*f/nr[1], relz/(nr[2]**2))
            # normal of ellipsoid at p: (dx/a^2, dy/b^2, dz/c^2) with offsets from the centre
            nrm = ((p[0]-nc[0])/nr[0]**2, (p[1]-nc[1])/nr[1]**2, (p[2]-nc[2])/nr[2]**2)
            pores.append(orient(torus(0.0036, 0.0012, 12, 6), nrm, p))
    pieces.append(("Poros nucleares", "nucleo", merge(pores), "poro"))
    ncut = nprof.cut_z
    nuc_c = (nc[0]+0.010, nc[1]+0.004, nc[2]+0.004)
    nuc_r = 0.016
    pieces.append(("Nucleolo", "nucleolo", sphere((nuc_r,)*3, center=nuc_c, segments=20, rings=11), "nucleolo"))
    labels["nucleolo"] = (nuc_c[0], nuc_c[1]-0.006, nuc_c[2]+nuc_r-0.001)
    labels["nucleo"] = ell_pt(nc, nr, -40, 0.008)

    # RER: cisternas planas que abrazan el nucleo, ribosomas anclados en su cara externa
    rer_meshes, ribos = [], []
    rr = 0.0030
    for k, phi in enumerate((130, 155, 180, 205, 230)):
        a = math.radians(phi)
        rho = 1/math.sqrt((math.cos(a)/nr[0])**2+(math.sin(a)/nr[1])**2)
        d = rho*0.97+0.0105+0.0026
        sheet = FlattenedCisterna(radii=(0.0215, 0.0105, 0.0035), wave=0.0008)
        rot, t = (0, 0, phi+90), (nc[0]+d*math.cos(a), nc[1]+d*math.sin(a), zt+0.004)
        rer_meshes.append(place(sheet.mesh(segments=24, rings=12), rot, t))
        for j in (2, 3, 4):
            for i in range(0, 24, 3):
                c, _ = sheet.anchor(math.pi*j/12, math.tau*i/24, offset=rr)
                ribos.append(blob((rr,)*3, place_pt(c, rot, t), seg=8, rings=5))
        if k == 2:
            rer_label = (t[0]-0.010*math.cos(a), t[1]-0.010*math.sin(a), zt+0.004+0.0035+0.001)
    pieces.append(("Cisternas RER", "rer", merge(rer_meshes), "rer"))
    labels["rer"] = rer_label
    ribos_anchored = ribos

    # REL: red tubular sin ribosomas, continua detras del RER
    rel = []
    def wav(p0, p1, amp, n=9, zb=0.004, zamp=0.0025):
        out = []
        dx, dy = p1[0]-p0[0], p1[1]-p0[1]
        L = math.hypot(dx, dy)
        nx, ny = -dy/L, dx/L
        for i in range(n):
            u = i/(n-1)
            w = amp*math.sin(math.tau*u*1.2)
            out.append((p0[0]+dx*u+nx*w, p0[1]+dy*u+ny*w, zt+zb+zamp*math.sin(math.tau*u*1.5+1)))
        return out
    paths = [wav((-0.092, 0.004), (-0.094, 0.052), 0.004),
             wav((-0.093, 0.036), (-0.078, 0.072), 0.004),
             wav((-0.094, 0.050), (-0.098, 0.060), 0.002, n=6)]
    for p in paths:
        rel.append(tube(p, 0.0042, 8))
    pieces.append(("Tubulos REL", "rel", merge(rel), "rel"))
    labels["rel"] = (paths[0][4][0], paths[0][4][1], paths[0][4][2]+0.0042)

    # Golgi: pila curva de cuatro cisternas con vesiculas en los extremos
    gc = (0.086, -0.018, zt)
    gol = []
    for k, rad in enumerate((0.022, 0.0215, 0.020, 0.017)):
        sheet = FlattenedCisterna(radii=(rad, 0.012, 0.0028), wave=0.0006)
        m = bend(sheet.mesh(segments=24, rings=10), 0.004/(0.021**2))
        gol.append(place(m, (0, 0, 20), (gc[0], gc[1], gc[2]+0.002+0.0066*k)))
    pieces.append(("Cisternas Golgi", "golgi", merge(gol), "golgi"))
    labels["golgi"] = (gc[0], gc[1], gc[2]+0.002+0.0066*3+0.0028+0.004*0.35)

    # mitocondrias: una abierta con crestas, dos cerradas
    mr = (0.028, 0.013, 0.013)
    mprof = CutawayProfile(radii=mr, cut_fraction=0.35, wall_fraction=0.10)
    mshell, mfill = mprof.shell(segments=24, rings=10), mprof.fill(clearance=0.05, inset=0.30, segments=24, rings=10)
    ix, iy, iz = mprof.inner_radii
    cr = []
    for x in (-0.018, -0.012, -0.006, 0.0, 0.006, 0.012, 0.018):
        cz, rz = 0.0, 0.0038
        q = 0.80-(x/ix)**2-(rz/iz)**2
        ry = iy*math.sqrt(max(q, 0.01))
        cr.append(sphere((0.0012, ry, rz), center=(x, 0, cz), segments=12, rings=6))
    mc, mrot = (0.040, -0.075, zt+0.007), (0, 0, 10)
    pieces.append(("Mitocondria abierta", "mitocondrias", place(mshell, mrot, mc), "mitocondrias"))
    pieces.append(("Matriz mitocondrial", "mitocondrias", place(mfill, mrot, mc), "mito_matriz"))
    pieces.append(("Crestas", "mitocondrias", place(merge(cr), mrot, mc), "mito_cresta"))
    mm = [blob((0.026, 0.012, 0.012), (x, y, zt+0.007), (0, 0, r), seg=16, rings=8)
          for (x, y), r in (((-0.062, -0.062), -20), ((0.072, 0.050), 80))]
    pieces.append(("Mitocondrias cerradas", "mitocondrias", merge(mm), "mitocondrias"))
    labels["mitocondrias"] = place_pt((0.0, 0.0, 0.0045), mrot, mc)

    # lisosomas con alturas variables
    lys = (((0.035, 0.083), 0.007), ((-0.026, -0.088), 0.004), ((0.102, 0.028), 0.008), ((-0.101, -0.030), 0.005))
    ls = [blob((0.0095,)*3, (x, y, zt+h), seg=12, rings=7) for (x, y), h in lys]
    pieces.append(("Lisosomas", "lisosomas", merge(ls), "lisosomas"))
    labels["lisosomas"] = (lys[0][0][0], lys[0][0][1], zt+lys[0][1]+0.0095)

    # centrosoma: dos centriolos (9 varillas) aprox. perpendiculares + matriz pericentriolar
    cx, cy = -0.004, -0.048
    L, rc = 0.022, 0.0065
    zc = zt+rc
    cen = [centriole(rc, L, (cx, cy, zc), 0),
           centriole(rc, L, (cx, cy-L/2-rc-0.0015, zc), 90),
           place(sphere((0.014, 0.012, 0.0022), segments=16, rings=6), (0, 0, 0), (cx, cy-0.011, zt+0.0005))]
    pieces.append(("Centriolos", "centrosoma", merge(cen), "centrosoma"))
    labels["centrosoma"] = (cx-0.004, cy, zc+rc+0.0005)

    # vesiculas alrededor de los extremos del Golgi y dispersas
    u = (math.cos(math.radians(20)), math.sin(math.radians(20)))
    v = (-u[1], u[0])
    ves = []
    for s_, o, h in ((0.032, 0.004, 0.004), (0.036, -0.006, 0.002), (0.030, -0.014, 0.005),
                     (-0.031, 0.004, 0.004), (-0.035, -0.006, 0.002), (-0.029, 0.012, 0.006)):
        ves.append((gc[0]+s_*u[0]+o*v[0], gc[1]+s_*u[1]+o*v[1], h))
    ves += [(-0.040, 0.092, 0.003), (0.020, -0.092, 0.003)]
    vs = [blob((0.0042,)*3, (x, y, zt+h), seg=10, rings=6) for x, y, h in ves]
    pieces.append(("Vesiculas", "vesiculas", merge(vs), "vesiculas"))
    labels["vesiculas"] = (ves[0][0], ves[0][1], zt+ves[0][2]+0.0042)

    # ribosomas libres, filamentos escasos y punto para etiqueta de citosol
    fring = [q for q in fill.vertices if q[2] > zt-0.002]
    fx, fy = max(abs(q[0]) for q in fring), max(abs(q[1]) for q in fring)
    occ = [q[:2] for _, _, m, _ in pieces[2:] for q in m.vertices]
    occ.extend(q[:2] for m in ribos_anchored for q in m.vertices)
    cand = [(-0.12+0.01*i, -0.10+0.01*j) for i in range(25) for j in range(21)
            if ((-0.12+0.01*i)/fx)**2+((-0.10+0.01*j)/fy)**2 < 0.55]

    def pick(n, clear):
        out = []
        for _ in range(n):
            best, bd = None, 0
            for c in cand:
                d = min(math.dist(c, o) for o in occ+out)
                if d > bd:
                    best, bd = c, d
            if best is None or bd < clear:
                break
            out.append(best)
        return out
    fr = pick(14, 0.010)
    occ.extend(fr)
    pieces.append(("Ribosomas", "ribosomas",
                   merge(ribos_anchored+[blob((rr,)*3, (x, y, zt+rr*0.8), seg=8, rings=5) for x, y in fr]), "ribosomas"))
    labels["ribosomas"] = (fr[0][0], fr[0][1], zt+rr*0.8+rr)
    fl = pick(5, 0.0)
    occ.extend(fl)
    cyt = []
    for (x, y), ang, bd in zip(fl, (10, 55, -35, 90, 30), (0.006, -0.006, 0.005, -0.005, 0.006)):
        a = math.radians(ang)
        du, dv = (math.cos(a), math.sin(a)), (-math.sin(a), math.cos(a))
        pts = []
        for i in range(7):
            w = -0.018+0.036*i/6
            pts.append((x+w*du[0]+bd*(1-(w/0.018)**2)*dv[0], y+w*du[1]+bd*(1-(w/0.018)**2)*dv[1], zt+0.0022))
        cyt.append(tube(pts, 0.0022, 6))
    pieces.append(("Filamentos", "citoesqueleto", merge(cyt), "citoesqueleto"))
    labels["citoesqueleto"] = (fl[0][0], fl[0][1], zt+0.0022+0.0024)
    cp = pick(1, 0.0)[0]
    labels["citoplasma"] = (cp[0], cp[1], zt+0.0005)

    return prof, pieces, labels, zt


def _contained(prof, pieces, zt):
    ix, iy, iz = prof.inner_radii
    bad = []
    for name, pid, m, _ in pieces:
        if pid in ("membrana", "citoplasma"):
            continue
        worst = max((v[0]/ix)**2+(v[1]/iy)**2+(v[2]/iz)**2 for v in m.vertices)
        top = max(v[2] for v in m.vertices)
        if worst > 0.88 or top > prof.cut_z+0.03:
            bad.append((name, round(worst, 3), round(top, 4)))
    return bad


def _transform_params(pieces):
    R = _rot(rx=TILT_DEG)
    pts = [_apply(R, v) for _, _, m, _ in pieces for v in m.vertices]
    lo = [min(p[k] for p in pts) for k in range(3)]
    hi = [max(p[k] for p in pts) for k in range(3)]
    s = 0.30/max(hi[k]-lo[k] for k in range(3))
    mid = [(lo[k]+hi[k])/2 for k in range(3)]
    return R, s, mid


def _tf(R, s, mid, p):
    q = _apply(R, p)
    return tuple((q[k]-mid[k])*s for k in range(3))


PALETTE = {
    "membrana": ((0.10, 0.36, 0.62), 0.45), "citoplasma": ((0.96, 0.90, 0.58), 0.7),
    "nucleo": ((0.40, 0.25, 0.62), 0.5), "nucleoplasma": ((0.72, 0.62, 0.86), 0.7),
    "nucleolo": ((0.35, 0.05, 0.38), 0.5), "rer": ((0.18, 0.50, 0.55), 0.55),
    "ribosomas": ((0.05, 0.08, 0.16), 0.6), "rel": ((0.55, 0.88, 0.45), 0.5),
    "golgi": ((0.95, 0.72, 0.15), 0.45), "mitocondrias": ((0.85, 0.22, 0.12), 0.5),
    "lisosomas": ((0.85, 0.05, 0.50), 0.4), "centrosoma": ((0.02, 0.42, 0.10), 0.4),
    "vesiculas": ((0.70, 0.95, 1.00), 0.35), "citoesqueleto": ((0.25, 0.32, 0.50), 0.5),
    "poro": ((0.16, 0.08, 0.30), 0.5), "mito_matriz": ((0.96, 0.60, 0.48), 0.6),
    "mito_cresta": ((0.50, 0.06, 0.08), 0.5),
}
NAMES = {"membrana": "Membrana", "citoplasma": "Citosol", "nucleo": "Envoltura nuclear",
         "nucleoplasma": "Nucleoplasma", "nucleolo": "Nucleolo", "rer": "RER", "ribosomas": "Ribosomas",
         "rel": "REL", "golgi": "Golgi", "mitocondrias": "Mitocondrias", "lisosomas": "Lisosomas",
         "centrosoma": "Centriolos", "vesiculas": "Vesiculas", "citoesqueleto": "Filamentos",
         "poro": "Poros nucleares", "mito_matriz": "Matriz mitocondrial", "mito_cresta": "Crestas"}


def build():
    prof, pieces, labels, zt = _layout()
    bad = _contained(prof, pieces, zt)
    if bad:
        raise ValueError("Pieces outside cavity: %r" % (bad,))
    R, s, mid = _transform_params(pieces)
    mats = {k: material("Celula · "+NAMES[k], c, roughness=r) for k, (c, r) in PALETTE.items()}
    for name, pid, m, key in pieces:
        tm = MeshData(tuple(_tf(R, s, mid, v) for v in m.vertices), m.faces)
        mesh_object(name, pid, tm, mats[key], smooth=(pid not in ("golgi", "rer")))
    parts = {pid: {"label_position": [round(c, 5) for c in _tf(R, s, mid, p)]} for pid, p in labels.items()}
    return {
        "title": "Celula animal · detalle (R9)",
        "design_notes": [
            "Cuenco abierto hacia arriba y el frente; citosol a ras del corte, organulos a alturas variables.",
            "Nucleo elevado con envoltura parcial, poros en toroide y nucleolo grande sin membrana.",
            "RER: cisternas planas que abrazan el nucleo con ribosomas anclados; REL tubular sin ribosomas.",
            "Golgi curvo de cuatro cisternas con vesiculas en sus extremos, lejos del nucleo.",
            "Mitocondria abierta con crestas visibles; dos centriolos de nueve varillas perpendiculares.",
            "Citoesqueleto escaso: cinco filamentos finos curvados, no radiales.",
        ],
        "parts": parts,
    }
