"""Célula animal educativa · réplica R4 · DETALLE v1 (desde blockout-v1 aprobado).

Mismo marco de corte que el blockout: plano de corte horizontal en Z local,
superficie pálida del citosol en z = P; al final se rota la normal del corte
hacia arriba y al frente (-Y), se escala con vértices reales a 0.30 m y se
centra. Detalle: cisternas aplanadas, ribosomas anclados al RER y libres, REL
tubular sin ribosomas, mitocondria abierta con crestas, núcleo con envoltura
parcial, poros y nucléolo, dos centríolos perpendiculares, Golgi curvo con
vesículas y citoesqueleto escaso. Sin E/S, luces, cámaras ni modificadores.
"""

import math
import random

from components import (CutawayProfile, FlattenedCisterna, MeshData, material,
                        mesh_object, sphere, validate_mesh)

TARGET = 0.30
# Normal del plano de corte en el mundo: arriba, hacia el frente (-Y) y un poco
# hacia +X, aproximando la cámara común (0.45, -0.60, 0.55).
CUT_NORMAL = (0.25, -0.55, 0.80)


# --------------------------------------------------------------------------
# Utilidades geométricas puras (sin bpy)
# --------------------------------------------------------------------------
def _norm(v):
    length = math.sqrt(sum(x*x for x in v))
    return tuple(x/length for x in v)


def _cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def _dot(a, b):
    return sum(x*y for x, y in zip(a, b))


def _rotation_z_to(n):
    """Matriz 3x3 (Rodrigues) que lleva +Z a n."""
    n = _norm(n)
    axis = _cross((0, 0, 1), n)
    s = math.sqrt(_dot(axis, axis))
    c = n[2]
    if s < 1e-12:
        return ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    k = tuple(x/s for x in axis)
    kx, ky, kz = k
    t = 1-c
    return ((c+kx*kx*t, kx*ky*t-kz*s, kx*kz*t+ky*s),
            (ky*kx*t+kz*s, c+ky*ky*t, ky*kz*t-kx*s),
            (kz*kx*t-ky*s, kz*ky*t+kx*s, c+kz*kz*t))


def _apply(m, v):
    return tuple(_dot(row, v) for row in m)


def _signed_volume(vertices, faces):
    o = vertices[0]
    vol = 0.0
    for f in faces:
        a, b, c = [tuple(x-y for x, y in zip(vertices[i], o)) for i in f]
        vol += _dot(a, _cross(b, c))/6
    return vol


def oriented(mesh):
    """Invierte el winding si una transformación lo dejó con volumen negativo."""
    if _signed_volume(mesh.vertices, mesh.faces) < 0:
        return MeshData(mesh.vertices, tuple((f[0], f[2], f[1]) for f in mesh.faces))
    return mesh


def mapped(mesh, fn):
    return oriented(MeshData(tuple(fn(v) for v in mesh.vertices), mesh.faces))


def merge(meshes):
    vertices, faces = [], []
    for m in meshes:
        off = len(vertices)
        vertices.extend(m.vertices)
        faces.extend(tuple(i+off for i in f) for f in m.faces)
    return MeshData(tuple(vertices), tuple(faces))


def yawed(mesh, yaw, center):
    c, s = math.cos(yaw), math.sin(yaw)
    return mapped(mesh, lambda v: (center[0]+c*v[0]-s*v[1], center[1]+s*v[0]+c*v[1], center[2]+v[2]))


def _catmull(points, samples):
    pts = [points[0]]+list(points)+[points[-1]]
    out = []
    for i in range(1, len(pts)-2):
        p0, p1, p2, p3 = pts[i-1], pts[i], pts[i+1], pts[i+2]
        for k in range(samples):
            t = k/samples
            t2, t3 = t*t, t*t*t
            out.append(tuple(0.5*((2*b)+(-a+c)*t+(2*a-5*b+4*c-d)*t2+(-a+3*b-3*c+d)*t3)
                             for a, b, c, d in zip(p0, p1, p2, p3)))
    out.append(tuple(points[-1]))
    return out


def tube(points, radius, *, sides=8, samples=4):
    """Tubo cerrado con tapas de vértice único, siguiendo una curva suave."""
    path = _catmull(points, samples) if len(points) > 2 else [tuple(points[0]), tuple(points[1])]
    tangents = []
    for i in range(len(path)):
        a = path[max(i-1, 0)]
        b = path[min(i+1, len(path)-1)]
        tangents.append(_norm(tuple(y-x for x, y in zip(a, b))))
    ref = (0, 0, 1) if abs(tangents[0][2]) < 0.9 else (1, 0, 0)
    normal = _norm(_cross(_cross(tangents[0], ref), tangents[0]))
    vertices, faces = [], []
    for i, (p, t) in enumerate(zip(path, tangents)):
        normal = _norm(tuple(x-_dot(normal, t)*y for x, y in zip(normal, t)))  # transporte paralelo
        binormal = _cross(t, normal)
        for k in range(sides):
            a = math.tau*k/sides
            vertices.append(tuple(p[j]+radius*(math.cos(a)*normal[j]+math.sin(a)*binormal[j]) for j in range(3)))
    rings = len(path)
    for r in range(rings-1):
        a, b = r*sides, (r+1)*sides
        for k in range(sides):
            n = (k+1) % sides
            faces.extend(((a+k, b+k, b+n), (a+k, b+n, a+n)))
    start = len(vertices)
    vertices.append(tuple(path[0]))
    end = len(vertices)
    vertices.append(tuple(path[-1]))
    last = (rings-1)*sides
    for k in range(sides):
        n = (k+1) % sides
        faces.append((start, k, n))
        faces.append((end, last+n, last+k))
    return oriented(MeshData(tuple(vertices), tuple(faces)))


def bend_map(center, radius, angle0, base_z):
    """Curva una pieza local (x tangente, y vertical, z radial) sobre un arco."""
    def fn(v):
        ang = angle0+v[0]/radius
        r = radius+v[2]
        return (center[0]+r*math.cos(ang), center[1]+r*math.sin(ang), base_z+v[1])
    return fn



def posed(mesh, center, yaw=0.0, pitch=0.0):
    """Inclina (pitch sobre el eje Y local), gira (yaw sobre Z) y traslada."""
    def fn(v):
        cp, sp = math.cos(pitch), math.sin(pitch)
        x, y, z = cp*v[0]+sp*v[2], v[1], -sp*v[0]+cp*v[2]
        c, s = math.cos(yaw), math.sin(yaw)
        return (center[0]+c*x-s*y, center[1]+s*x+c*y, center[2]+z)
    return mapped(mesh, fn), fn


def torus(major, minor, *, center, normal, segments=10, sides=5):
    """Anillo cerrado cuyo eje sigue `normal`; sugiere un poro nuclear."""
    rot = _rotation_z_to(normal)
    vertices, faces = [], []
    for i in range(segments):
        u = math.tau*i/segments
        for k in range(sides):
            w = math.tau*k/sides
            r = major+minor*math.cos(w)
            p = _apply(rot, (r*math.cos(u), r*math.sin(u), minor*math.sin(w)))
            vertices.append(tuple(a+b for a, b in zip(p, center)))
    for i in range(segments):
        ni = (i+1) % segments
        for k in range(sides):
            nk = (k+1) % sides
            a, b, c, d = i*sides+k, ni*sides+k, ni*sides+nk, i*sides+nk
            faces.extend(((a, b, c), (a, c, d)))
    return oriented(MeshData(tuple(vertices), tuple(faces)))


def open_mitochondrion(center, yaw):
    """Mitocondria abierta: membrana externa en cuenco, matriz y crestas transversales."""
    radii = (0.17, 0.08, 0.075)
    prof = CutawayProfile(radii=radii, cut_fraction=0.15, wall_fraction=0.12, center=(0, 0, 0))
    seg, rings = 32, 10
    outer = prof.shell(segments=seg, rings=rings)
    matrix = prof.fill(segments=seg, rings=rings, clearance=0.03, inset=0.35)
    inner = prof.inner_radii
    top = prof.cut_z-0.004
    cristae = []
    for idx, x in enumerate((-0.105, -0.063, -0.021, 0.021, 0.063, 0.105)):
        w = inner[1]*math.sqrt(1-(x/inner[0])**2)
        half_h = 0.021
        zc = top-half_h
        # Contención en el elipsoide interior en las esquinas de la placa.
        reach = 0.62*w
        side = 1 if idx % 2 == 0 else -1
        yc = side*(w-reach)*0.98
        plate = FlattenedCisterna(radii=(reach, half_h, 0.0055), wave=0.0, center=(0, 0, 0))
        cristae.append(mapped(plate.mesh(segments=16, rings=8),
                              lambda v, x=x, yc=yc, zc=zc: (x+v[2], yc+v[0], zc+v[1])))
    parts = []
    for name, mesh, key in (('membrana externa', outer, 'mitocondrias'), ('matriz', matrix, 'matriz'),
                            ('crestas', merge(cristae), 'crestas')):
        m, fn = posed(mesh, center, yaw)
        parts.append((name, m, key))
    label = posed(sphere((0.01,)*3), center, yaw)[1]((0.0, 0.0, top+0.01))
    return parts, label


def centriole(base, axis_dir, length, *, barrel=0.030, rod=0.0085):
    """Barril de nueve microtúbulos (triplete simplificado) a lo largo de axis_dir."""
    t = _norm(axis_dir)
    ref = (0, 0, 1) if abs(t[2]) < 0.9 else (1, 0, 0)
    a = _norm(_cross(t, ref))
    b = _cross(t, a)
    rods = []
    for i in range(9):
        ang = math.tau*i/9
        off = tuple(barrel*(math.cos(ang)*a[j]+math.sin(ang)*b[j]) for j in range(3))
        p0 = tuple(base[j]+off[j] for j in range(3))
        p1 = tuple(base[j]+off[j]+length*t[j] for j in range(3))
        rods.append(tube([p0, p1], rod, sides=6))
    return merge(rods)


# --------------------------------------------------------------------------
# Composición en el marco local del corte
# --------------------------------------------------------------------------
def compose():
    rng = random.Random(20261022)
    items = []   # (nombre, part_id, MeshData, clave de material, smooth)
    labels = {}

    # Membrana y citosol (mismo perfil y misma teselación).
    cell = CutawayProfile(radii=(1.0, 0.94, 0.84), cut_fraction=0.12,
                          wall_fraction=0.06, center=(0, 0, 0))
    seg, rings = 64, 24
    items.append(('envoltura abierta', 'membrana', cell.shell(segments=seg, rings=rings), 'membrana', False))
    inset = 0.06
    items.append(('citosol', 'citoplasma', cell.fill(segments=seg, rings=rings, clearance=0.02, inset=inset),
                  'citoplasma', False))
    P = cell.cut_z-inset*cell.radii[2]   # superficie del citosol
    cut_ry = cell.radii[1]*math.sqrt(1-cell.cut_fraction**2)
    labels['membrana'] = (0.0, cut_ry, cell.cut_z+0.02)
    labels['citoplasma'] = (-0.30, -0.24, P+0.01)

    # Núcleo: envoltura abierta (parcial), poros, nucleoplasma y nucléolo sin membrana.
    N = (-0.12, 0.12)
    nzc = P+0.08
    nr = (0.30, 0.30, 0.28)
    nuc = CutawayProfile(radii=nr, cut_fraction=0.40, wall_fraction=0.08, center=(N[0], N[1], nzc))
    items.append(('envoltura nuclear', 'nucleo', nuc.shell(segments=48, rings=16), 'nucleo', False))
    nuc_inset = 0.06
    items.append(('nucleoplasma', 'nucleo', nuc.fill(segments=48, rings=16, clearance=0.03, inset=nuc_inset),
                  'nucleoplasma', False))
    pores = []
    for row, theta_deg in enumerate((80.0, 96.0)):
        theta = math.radians(theta_deg)
        for i in range(14):
            phi = math.tau*(i+0.5*row)/14
            d = (math.sin(theta)*math.cos(phi), math.sin(theta)*math.sin(phi), math.cos(theta))
            surf = (N[0]+nr[0]*d[0], N[1]+nr[1]*d[1], nzc+nr[2]*d[2])
            normal = _norm((d[0]/nr[0], d[1]/nr[1], d[2]/nr[2]))
            center = tuple(s+0.003*n for s, n in zip(surf, normal))
            pores.append(torus(0.022, 0.0075, center=center, normal=normal))
    items.append(('poros nucleares', 'nucleo', merge(pores), 'poros', True))
    nuc_top = nuc.cut_z-nuc_inset*nuc.radii[2]
    nl_c = (N[0]+0.03, N[1]+0.03, nuc_top)
    items.append(('nucleolo', 'nucleolo', sphere((0.085, 0.085, 0.075), center=nl_c, segments=24, rings=12),
                  'nucleolo', True))
    labels['nucleo'] = (N[0]-0.30, N[1]+0.02, nuc.cut_z+0.01)
    labels['nucleolo'] = (nl_c[0], nl_c[1], nl_c[2]+0.08)

    # RER: cisternas aplanadas en arcos concéntricos junto al núcleo, con ribosomas
    # anclados en su cara citoplasmática externa (anclajes de rejilla de la biblioteca).
    rer_mesh, ribo_attached = [], []
    rer_angle = math.radians(-55)
    rer_radii = (0.365, 0.43, 0.495)
    for k, R in enumerate(rer_radii):
        a = 0.20+0.02*k
        cist = FlattenedCisterna(radii=(a, 0.095, 0.016), wave=0.0, center=(0, 0, 0))
        fn = bend_map(N, R, rer_angle, P+0.03-0.012*k)
        rer_mesh.append(mapped(cist.mesh(segments=32, rings=16), fn))
        for j in (3, 4, 5, 6, 7):
            for i in range(1, 16):
                if (i+j) % 2:
                    continue
                theta, phi = math.pi*j/16, math.tau*i/32
                point, _ = cist.anchor(theta, phi, offset=0.0095)
                if point[1] < -0.01:
                    continue
                ribo_attached.append(sphere((0.0095,)*3, center=fn(point), segments=6, rings=4))
    items.append(('cisternas rugosas', 'rer', merge(rer_mesh), 'rer', True))
    labels['rer'] = (N[0]+0.43*math.cos(rer_angle), N[1]+0.43*math.sin(rer_angle), P+0.14)

    # REL: túbulos ramificados que se hunden y reaparecen en el citosol; sin ribosomas.
    z = P+0.010
    rel_paths = [
        [(-0.17, -0.37, z+0.02), (-0.26, -0.43, z+0.03), (-0.36, -0.40, z), (-0.46, -0.45, z+0.02), (-0.53, -0.39, z-0.004)],
        [(-0.26, -0.43, z+0.03), (-0.31, -0.52, z+0.01), (-0.40, -0.58, z+0.03), (-0.49, -0.55, z-0.004)],
        [(-0.36, -0.40, z), (-0.40, -0.30, z+0.025), (-0.48, -0.27, z+0.005)],
        [(-0.31, -0.52, z+0.01), (-0.21, -0.58, z+0.035), (-0.12, -0.66, z+0.005)],
    ]
    items.append(('tubulos lisos', 'rel', merge([tube(p, 0.022, sides=10) for p in rel_paths]), 'rel', True))
    labels['rel'] = (-0.40, -0.48, z+0.06)

    # Golgi: pila de cisternas curvas con bordes dilatados, más lejos que el RER.
    u = _norm((0.60, -0.10, 0.0))
    C = (N[0]+u[0]*0.95, N[1]+u[1]*0.95)
    to_nucleus = math.atan2(-u[1], -u[0])
    golgi = []
    g_specs = ((0.38, 0.16, 0.035), (0.33, 0.145, 0.045), (0.28, 0.13, 0.055), (0.23, 0.11, 0.065))
    for r, a, zb in g_specs:
        cist = FlattenedCisterna(radii=(a, 0.075, 0.015), wave=0.0, center=(0, 0, 0))
        fn = bend_map(C, r, to_nucleus, P+zb)
        golgi.append(mapped(cist.mesh(segments=28, rings=12), fn))
        for end in (-1, 1):
            golgi.append(sphere((0.024,)*3, center=fn((end*(a-0.012), 0.035, 0.0)), segments=10, rings=6))
    items.append(('pila de cisternas', 'golgi', merge(golgi), 'golgi', True))
    g_mid = (C[0]+0.30*math.cos(to_nucleus), C[1]+0.30*math.sin(to_nucleus))
    labels['golgi'] = (g_mid[0], g_mid[1], P+0.14)

    # Vesículas: brotando de la cara trans, en tránsito RER→Golgi y hacia la membrana.
    trans_r = 0.17
    ves_specs = []
    for d, h in ((-0.30, 0.07), (-0.10, 0.11), (0.10, 0.06), (0.32, 0.09)):
        ang = to_nucleus+d
        ves_specs.append((C[0]+trans_r*math.cos(ang), C[1]+trans_r*math.sin(ang), P+h, 0.028))
    ves_specs += [(0.70, -0.08, P+0.03, 0.030), (0.66, 0.26, P+0.045, 0.030), (0.36, 0.06, P+0.08, 0.024),
                  (0.42, -0.17, P+0.05, 0.024), (0.30, 0.22, P+0.03, 0.030), (0.12, -0.63, P+0.02, 0.032),
                  (-0.55, 0.12, P+0.04, 0.030), (0.78, 0.05, P+0.012, 0.026)]
    ves = [sphere((r,)*3, center=(x, y, h), segments=12, rings=7) for x, y, h, r in ves_specs]
    items.append(('vesiculas', 'vesiculas', merge(ves), 'vesiculas', True))
    labels['vesiculas'] = (ves_specs[1][0], ves_specs[1][1], ves_specs[1][2]+0.05)

    # Mitocondrias: una abierta con crestas y dos cerradas inclinadas a distinta altura.
    m_open = (0.40, -0.42)
    mparts, mlabel = open_mitochondrion((m_open[0], m_open[1], P+0.035), math.radians(30))
    for name, mesh, key in mparts:
        items.append((name, 'mitocondrias', mesh, key, key != 'mitocondrias'))
    closed_specs = [((-0.62, -0.10), math.radians(80), math.radians(14), P+0.03),
                    ((0.05, 0.62), math.radians(-8), math.radians(-16), P+0.045)]
    for idx, ((x, y), yaw, pitch, h) in enumerate(closed_specs):
        body = sphere((0.14, 0.062, 0.058), segments=24, rings=12)
        items.append((f'mitocondria {idx+2}', 'mitocondrias', posed(body, (x, y, h), yaw, pitch)[0],
                      'mitocondrias', True))
    labels['mitocondrias'] = tuple(mlabel)

    # Lisosomas: semihundidos a distintas profundidades.
    lys_specs = [(-0.60, 0.30, P+0.005, 0.048), (0.66, -0.32, P+0.03, 0.044),
                 (-0.30, 0.52, P+0.018, 0.050), (-0.46, -0.16, P+0.028, 0.036)]
    lys = [sphere((r,)*3, center=(x, y, h), segments=16, rings=10) for x, y, h, r in lys_specs]
    items.append(('lisosomas', 'lisosomas', merge(lys), 'lisosomas', True))
    labels['lisosomas'] = (-0.30, 0.52, P+0.09)

    # Centrosoma: matriz pericentriolar y dos centríolos perpendiculares.
    cs = (0.18, 0.40, P+0.05)
    items.append(('matriz pericentriolar', 'centrosoma',
                  sphere((0.11, 0.085, 0.03), center=(cs[0]+0.05, cs[1]+0.02, P), segments=20, rings=8),
                  'pcm', True))
    c1 = centriole((cs[0]-0.06, cs[1], cs[2]), (1, 0, 0), 0.12)
    c2 = centriole((cs[0]+0.14, cs[1]+0.04, P-0.01), (0, 0, 1), 0.12)
    items.append(('centriolos', 'centrosoma', merge([c1, c2]), 'centrosoma', True))
    labels['centrosoma'] = (cs[0]+0.05, cs[1]+0.03, cs[2]+0.10)

    # Citoesqueleto escaso: filamentos corticales y dos microtúbulos desde el
    # centrosoma hacia zonas libres (ninguno cruza el RER ni toca el núcleo).
    fz = P+0.010
    def rim(t0, t1, sx, sy, n=6):
        return [(sx*math.cos(math.radians(t0+(t1-t0)*i/(n-1))),
                 sy*math.sin(math.radians(t0+(t1-t0)*i/(n-1))), fz) for i in range(n)]
    fil = [rim(95, 150, 0.765, 0.72), rim(200, 238, 0.80, 0.755), rim(-40, -8, 0.78, 0.736),
           rim(40, 75, 0.765, 0.72),
           [(cs[0]+0.02, cs[1]+0.07, fz+0.01), (0.28, 0.55, fz+0.02), (0.40, 0.58, fz)],
           [(cs[0]+0.11, cs[1]-0.02, fz+0.01), (0.46, 0.33, fz+0.025), (0.58, 0.40, fz)]]
    items.append(('filamentos', 'citoesqueleto', merge([tube(p, 0.010, sides=6) for p in fil]),
                  'citoesqueleto', True))
    labels['citoesqueleto'] = (0.765*math.cos(math.radians(120)), 0.72*math.sin(math.radians(120)), fz+0.03)

    # Ribosomas libres: dispersión con rechazo para no invadir otras piezas.
    obstacles = [(N[0], N[1], 0.34), (cs[0]+0.04, cs[1], 0.15), (C[0]-0.30*u[0], C[1]-0.30*u[1], 0.20),
                 (m_open[0], m_open[1], 0.19)]
    obstacles += [(x, y, 0.16) for (x, y), *_ in closed_specs]
    obstacles += [(x, y, r+0.03) for x, y, _, r in lys_specs]
    obstacles += [(x, y, r+0.03) for x, y, _, r in ves_specs]
    obstacles += [(x, y, 0.05) for p in rel_paths for x, y, _ in p]
    obstacles += [(N[0]+R*math.cos(rer_angle+d), N[1]+R*math.sin(rer_angle+d), 0.06)
                  for R in rer_radii for d in (-0.6, -0.3, 0, 0.3, 0.6)]
    obstacles += [(x, y, 0.03) for p in fil for x, y, _ in p]
    free = []
    tries = 0
    while len(free) < 48 and tries < 8000:
        tries += 1
        x, y = rng.uniform(-0.78, 0.78), rng.uniform(-0.72, 0.72)
        if (x/0.76)**2+(y/0.70)**2 > 1:
            continue
        if any((x-ox)**2+(y-oy)**2 < r*r for ox, oy, r in obstacles):
            continue
        if any((x-fx)**2+(y-fy)**2 < 0.05**2 for fx, fy, _ in free):
            continue
        free.append((x, y, P+rng.uniform(0.002, 0.016)))
    ribo = ribo_attached+[sphere((0.0105,)*3, center=c, segments=6, rings=4) for c in free]
    items.append(('ribosomas', 'ribosomas', merge(ribo), 'ribosomas', True))
    rf = free[0] if free else (0.0, -0.5, P)
    labels['ribosomas'] = (rf[0], rf[1], rf[2]+0.035)

    return items, labels


def to_world(items, labels):
    """Rota el marco de corte, ajusta a 0.30 m con vértices reales y centra."""
    rot = _rotation_z_to(CUT_NORMAL)
    rotated = [(n, p, MeshData(tuple(_apply(rot, v) for v in m.vertices), m.faces), k, s)
               for n, p, m, k, s in items]
    lo = [min(v[i] for _, _, m, _, _ in rotated for v in m.vertices) for i in range(3)]
    hi = [max(v[i] for _, _, m, _, _ in rotated for v in m.vertices) for i in range(3)]
    scale = TARGET/max(h-l for h, l in zip(hi, lo))
    mid = [(h+l)/2 for h, l in zip(hi, lo)]

    def world(v):
        return tuple((v[i]-mid[i])*scale for i in range(3))
    out = [(n, p, MeshData(tuple(world(v) for v in m.vertices), m.faces), k, s) for n, p, m, k, s in rotated]
    lab = {key: [round(x, 6) for x in world(_apply(rot, v))] for key, v in labels.items()}
    return out, lab, scale


COLORS = {
    'membrana': ((0.80, 0.42, 0.40), 0.55),
    'citoplasma': ((0.80, 0.90, 0.86), 0.75),
    'nucleo': ((0.28, 0.20, 0.52), 0.5),
    'nucleoplasma': ((0.58, 0.48, 0.78), 0.7),
    'nucleolo': ((0.20, 0.06, 0.28), 0.5),
    'rer': ((0.22, 0.42, 0.82), 0.5),
    'ribosomas': ((0.06, 0.05, 0.16), 0.5),
    'rel': ((0.25, 0.68, 0.55), 0.5),
    'golgi': ((0.95, 0.68, 0.16), 0.5),
    'mitocondrias': ((0.80, 0.22, 0.07), 0.5),
    'matriz': ((0.96, 0.62, 0.36), 0.7),
    'crestas': ((0.55, 0.10, 0.04), 0.5),
    'poros': ((0.12, 0.08, 0.30), 0.5),
    'pcm': ((0.93, 0.74, 0.84), 0.75),
    'lisosomas': ((0.42, 0.74, 0.22), 0.5),
    'vesiculas': ((1.0, 0.88, 0.48), 0.45),
    'centrosoma': ((0.72, 0.18, 0.52), 0.5),
    'citoesqueleto': ((0.30, 0.30, 0.36), 0.6),
}


def build():
    items, labels = compose()
    items, labels, _scale = to_world(items, labels)
    mats = {key: material('R4 · '+key, color, roughness=rough) for key, (color, rough) in COLORS.items()}
    for name, part, mesh, key, smooth in items:
        validate_mesh(mesh)
        mesh_object(name, part, mesh, mats[key], smooth=smooth)
    return {
        'title': 'Célula animal · corte abierto (detalle R4)',
        'design_notes': [
            'Envoltura cortada por un plano inclinado hacia arriba y al frente; el citosol pálido forma la superficie de corte.',
            'Orgánulos semihundidos en el citosol a distintas alturas e inclinaciones para leer volumen interior.',
            'Núcleo con envoltura parcial abierta, poros sugeridos como anillos y nucléolo sin membrana; sin cromosomas en X.',
            'RER: cisternas aplanadas junto al núcleo con ribosomas en la cara citoplasmática; REL tubular sin ribosomas; ribosomas libres.',
            'Golgi: cisternas curvas con bordes dilatados y vesículas en la cara trans; más alejado del núcleo que el RER.',
            'Una mitocondria abierta muestra matriz y crestas interiores; dos centríolos de nueve túbulos perpendiculares.',
            'Citoesqueleto escaso: filamentos corticales y dos microtúbulos cortos, sin radiar del centrosoma en todas direcciones.',
            'Escala de maqueta: dimensión mayor 0.30 m ajustada con los vértices reales; no es escala microscópica.',
        ],
        'parts': {key: {'label_position': pos} for key, pos in labels.items()},
    }
