"""Célula animal educativa · DETALLE v1 (réplica R1), derivado de blockout-v1 aprobado.

Contrato: build() sin argumentos; sólo mallas MESH con part_id; sin E/S.
Marco local de diseño: Z hacia la cara de corte, después se inclina la célula
alrededor de X para que el corte mire hacia arriba y hacia el frente (-Y). Por
último se escala uniformemente con los vértices reales para que la dimensión
mayor sea 0.30 m y se centra la caja envolvente en el origen.
"""
import math
import random

from components import CutawayProfile, FlattenedCisterna, MeshData, material, mesh_object, sphere

TARGET = 0.30
TILT = math.radians(35.0)  # El corte mira a (0, -sin, cos): arriba y al frente.

# ---------------------------------------------------------------- utilidades

def _merge(meshes):
    vertices, faces = [], []
    for mesh in meshes:
        offset = len(vertices)
        vertices.extend(mesh.vertices)
        faces.extend(tuple(offset+i for i in face) for face in mesh.faces)
    return MeshData(tuple(vertices), tuple(faces))


def _map(mesh, fn):
    return MeshData(tuple(fn(v) for v in mesh.vertices), mesh.faces)


def _rot_z(mesh, angle, center):
    c, s = math.cos(angle), math.sin(angle)
    return _map(mesh, lambda v: (center[0]+c*v[0]-s*v[1], center[1]+s*v[0]+c*v[1], center[2]+v[2]))


def _bend(point, center, radius, angle0):
    """Curva una lámina local (x a lo largo, y ancho) en un arco alrededor de center.

    r = R - y conserva la orientación (winding exterior)."""
    x, y, z = point
    a = angle0+x/radius
    r = radius-y
    return (center[0]+r*math.cos(a), center[1]+r*math.sin(a), center[2]+z)


def _bend_normal(point, normal, radius, angle0):
    a = angle0+point[0]/radius
    t = (-math.sin(a), math.cos(a))
    rd = (math.cos(a), math.sin(a))
    n = (normal[0]*t[0]-normal[1]*rd[0], normal[0]*t[1]-normal[1]*rd[1], normal[2])
    length = math.sqrt(sum(k*k for k in n))
    return tuple(k/length for k in n)


def _catmull(points, steps):
    if len(points) < 3:
        return list(points)
    pts = [points[0]]+list(points)+[points[-1]]
    out = []
    for i in range(1, len(pts)-2):
        p0, p1, p2, p3 = pts[i-1], pts[i], pts[i+1], pts[i+2]
        for s in range(steps):
            t = s/steps
            t2, t3 = t*t, t*t*t
            out.append(tuple(0.5*((2*p1[k])+(-p0[k]+p2[k])*t+(2*p0[k]-5*p1[k]+4*p2[k]-p3[k])*t2
                                  + (-p0[k]+3*p1[k]-3*p2[k]+p3[k])*t3) for k in range(3)))
    out.append(tuple(points[-1]))
    return out


def _norm(v):
    length = math.sqrt(sum(k*k for k in v))
    return tuple(k/length for k in v)


def _cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def tube(points, radius, *, sides=8, steps=6):
    """Tubo cerrado con tapas planas en abanico (marcos de transporte paralelo)."""
    path = _catmull(points, steps)
    tangents = []
    for i in range(len(path)):
        a = path[max(i-1, 0)]
        b = path[min(i+1, len(path)-1)]
        tangents.append(_norm(tuple(b[k]-a[k] for k in range(3))))
    t0 = tangents[0]
    helper = (0, 0, 1) if abs(t0[2]) < 0.9 else (1, 0, 0)
    normal = _norm(_cross(_cross(t0, helper), t0))
    vertices, faces = [], []
    for i, (p, t) in enumerate(zip(path, tangents)):
        if i:
            normal = _norm(tuple(normal[k]-sum(normal[m]*t[m] for m in range(3))*t[k] for k in range(3)))
        binormal = _cross(t, normal)
        for s in range(sides):
            a = math.tau*s/sides
            vertices.append(tuple(p[k]+radius*(math.cos(a)*normal[k]+math.sin(a)*binormal[k]) for k in range(3)))
    n = len(path)
    for i in range(n-1):
        a, b = i*sides, (i+1)*sides
        for s in range(sides):
            nx = (s+1) % sides
            faces.extend(((a+s, a+nx, b+nx), (a+s, b+nx, b+s)))
    start, end = len(vertices), len(vertices)+1
    vertices.append(tuple(path[0]))
    vertices.append(tuple(path[-1]))
    last = (n-1)*sides
    for s in range(sides):
        nx = (s+1) % sides
        faces.append((start, nx, s))
        faces.append((end, last+s, last+nx))
    mesh = MeshData(tuple(vertices), tuple(faces))
    if _signed_volume(mesh) < 0:
        mesh = MeshData(mesh.vertices, tuple((f[0], f[2], f[1]) for f in mesh.faces))
    return mesh


def _signed_volume(mesh):
    o = mesh.vertices[0]
    total = 0.0
    for f in mesh.faces:
        a, b, c = [tuple(mesh.vertices[i][k]-o[k] for k in range(3)) for i in f]
        total += sum(x*y for x, y in zip(a, _cross(b, c)))/6
    return total


def _label_on(mesh, lift=0.0015):
    """Vértice de la cara superior más próximo al centroide horizontal."""
    vs = mesh.vertices
    zmax = max(v[2] for v in vs)
    zmin = min(v[2] for v in vs)
    cx = sum(v[0] for v in vs)/len(vs)
    cy = sum(v[1] for v in vs)/len(vs)
    top = [v for v in vs if v[2] >= zmax-0.3*(zmax-zmin)]
    v = min(top, key=lambda p: (p[0]-cx)**2+(p[1]-cy)**2)
    return (v[0], v[1], v[2]+lift)


# ---------------------------------------------------------------- detalle

def _bump(x, y, fx, fy):
    """Relieve suave del citosol (±1.2 mm), nulo en el borde del relleno."""
    rho = min(1.0, (x/fx)**2+(y/fy)**2)
    taper = 1.0-rho*rho
    return 0.0012*taper*(math.sin(52*x+0.7)*math.cos(47*y-0.3)+0.45*math.sin(31*y+29*x))


def _relief_fill(fill, z_top, segments, fx, fy, levels=7):
    """Sustituye el abanico plano superior por anillos con relieve, misma frontera."""
    top = len(fill.vertices)-1
    keep = [f for f in fill.faces if top not in f]
    vertices = list(fill.vertices[:-1])
    ring = list(range(segments))  # el primer anillo del casquete es el borde del corte
    center = fill.vertices[top]
    outer = ring
    for level in range(levels-1, 0, -1):
        k = level/levels
        inner = []
        for i in ring:
            v = vertices[i]
            x, y = center[0]+k*(v[0]-center[0]), center[1]+k*(v[1]-center[1])
            inner.append(len(vertices))
            vertices.append((x, y, z_top+_bump(x, y, fx, fy)))
        for i in range(segments):
            nx = (i+1) % segments
            keep.append((inner[i], outer[i], outer[nx]))
            keep.append((inner[i], outer[nx], inner[nx]))
        outer = inner
    c = len(vertices)
    vertices.append((center[0], center[1], z_top+_bump(center[0], center[1], fx, fy)))
    for i in range(segments):
        keep.append((c, outer[i], outer[(i+1) % segments]))
    return MeshData(tuple(vertices), tuple(keep))


def _place(mesh, angle, offset):
    return _rot_z(mesh, angle, offset)


def layout():
    """Devuelve (piezas, etiquetas, notas) en el marco local, sin bpy."""
    pieces = []   # (nombre, part_id, MeshData, clave de material, smooth)
    labels = {}
    footprints = []  # (x, y, radio) ocupados sobre la superficie del citoplasma

    def add(name, part, mesh, mat, smooth=True):
        pieces.append((name, part, mesh, mat, smooth))
        return mesh

    # Membrana: cuenco abierto con labio continuo; citosol contenido con relieve.
    seg, rings = 64, 20
    cell = CutawayProfile(radii=(0.150, 0.130, 0.110), cut_fraction=0.20, wall_fraction=0.06)
    add('envoltura abierta', 'membrana', cell.shell(segments=seg, rings=rings), 'membrana', False)
    inset = 0.10
    flat = cell.fill(clearance=0.02, inset=inset, segments=seg, rings=rings)
    z_top = cell.cut_z-inset*cell.radii[2]
    top_ring = [v for v in flat.vertices if v[2] >= z_top-1e-9]
    fx = max(abs(v[0]) for v in top_ring)
    fy = max(abs(v[1]) for v in top_ring)
    add('citosol', 'citoplasma', _relief_fill(flat, z_top, seg, fx, fy), 'citoplasma', True)

    def zs(x, y):
        return z_top+_bump(x, y, fx, fy)

    def inside(x, y, r=0.0, margin=0.94):
        return (x/(fx*margin-r))**2+(y/(fy*margin-r))**2 <= 1.0

    phi = math.radians(70)
    s = math.sqrt(1-cell.cut_fraction**2)
    labels['membrana'] = (cell.radii[0]*s*math.cos(phi), cell.radii[1]*s*math.sin(phi), cell.cut_z+0.002)

    # Núcleo: envoltura doble abierta (parcial) con poros, nucleoplasma, cromatina y nucléolo.
    N = (-0.030, 0.025)
    zn = z_top-0.006
    cut_n = z_top+0.012
    outer_r = (0.050, 0.046, 0.044)
    inner_r = tuple(0.945*r for r in outer_r)
    env_out = CutawayProfile(radii=outer_r, center=(N[0], N[1], zn), cut_fraction=(cut_n-zn)/outer_r[2],
                             wall_fraction=0.04)
    env_in = CutawayProfile(radii=inner_r, center=(N[0], N[1], zn), cut_fraction=(cut_n-zn)/inner_r[2],
                            wall_fraction=0.05)
    add('membrana nuclear externa', 'nucleo', env_out.shell(segments=48, rings=14), 'nucleo')
    add('membrana nuclear interna', 'nucleo', env_in.shell(segments=48, rings=14), 'nucleo')
    add('nucleoplasma', 'nucleo', env_in.fill(clearance=0.05, inset=0.12, segments=48, rings=14), 'nucleoplasma')
    z_np = env_in.cut_z-0.12*inner_r[2]
    footprints.append((N[0], N[1], 0.052))

    def cut_radius(radii, cz):
        return math.sqrt(1-((cz-zn)/radii[2])**2)

    # Poros: perlas oscuras que unen ambas membranas en el labio y puntos en la cara externa.
    k_out_in = cut_radius(tuple(0.96*r for r in outer_r), cut_n)*0.96
    k_in_out = cut_radius(inner_r, cut_n)*0.945
    k_mid = (k_out_in+k_in_out)/2
    pores = []
    for i in range(22):
        a = math.tau*(i+0.5)/22
        pores.append(sphere((0.0013,)*3, center=(N[0]+outer_r[0]*k_mid*math.cos(a),
                                                N[1]+outer_r[1]*k_mid*math.sin(a), cut_n),
                            segments=6, rings=4))
    zp = z_top+0.0055
    kp = math.sqrt(1-((zp-zn)/outer_r[2])**2)
    for i in range(18):
        a = math.tau*i/18
        ex, ey = outer_r[0]*kp*math.cos(a), outer_r[1]*kp*math.sin(a)
        nrm = _norm((ex/outer_r[0]**2, ey/outer_r[1]**2, 0.0))
        pores.append(sphere((0.0016, 0.0016, 0.0016),
                            center=(N[0]+ex+0.0004*nrm[0], N[1]+ey+0.0004*nrm[1], zp), segments=6, rings=4))
    add('poros nucleares', 'nucleo', _merge(pores), 'poros')
    rim_phi = math.radians(205)
    labels['nucleo'] = (N[0]+outer_r[0]*k_mid*math.cos(rim_phi), N[1]+outer_r[1]*k_mid*math.sin(rim_phi),
                        cut_n+0.0025)

    nucleolus_c = (N[0]+0.006, N[1]+0.004, z_top+0.004)
    nucleolus = add('nucleolo', 'nucleolo', sphere((0.015, 0.014, 0.012), center=nucleolus_c,
                                                   segments=28, rings=14), 'nucleolo')
    labels['nucleolo'] = _label_on(nucleolus)
    chroma = []
    for i in range(11):
        a = math.tau*i/11+0.3
        r = 0.026+0.006*((i*7) % 3)/2
        x, y = N[0]+r*math.cos(a)*0.95, N[1]+r*math.sin(a)*0.92
        chroma.append(_rot_z(sphere((0.0035, 0.0018, 0.0012), segments=8, rings=5), a*1.7,
                             (x, y, z_np+0.0002)))
    add('cromatina', 'nucleo', _merge(chroma), 'cromatina')

    # RER: tres cisternas aplanadas en arco junto al núcleo, ribosomas en su cara citoplasmática.
    rer_center_angle = math.radians(-45)
    rer_half = math.radians(50)
    rer_meshes, bound = [], []
    rib_r = 0.0018
    rer_z = z_top+0.0018
    for k, R in enumerate((0.060, 0.0705, 0.081)):
        sheet = FlattenedCisterna(radii=(R*rer_half, 0.0045, 0.0021), wave=0.0010, center=(0, 0, 0))
        a0 = rer_center_angle+(0.02 if k == 1 else 0.0)
        local = sheet.mesh(segments=48, rings=8)
        rer_meshes.append(_map(local, lambda v, R=R, a0=a0: _bend(v, (N[0], N[1], rer_z), R, a0)))
        for j in (2, 3, 4):
            for i in range((k+j) % 4, 48, 4):
                theta, ph = math.pi*j/8, math.tau*i/48
                point, normal = sheet.surface(theta, ph)
                world = _bend(point, (N[0], N[1], rer_z), R, a0)
                wn = _bend_normal(point, normal, R, a0)
                bound.append(sphere((rib_r,)*3, center=tuple(world[m]+rib_r*wn[m] for m in range(3)),
                                    segments=6, rings=4))
    add('cisternas RER', 'rer', _merge(rer_meshes), 'rer')
    labels['rer'] = (N[0]+0.0705*math.cos(rer_center_angle+0.02), N[1]+0.0705*math.sin(rer_center_angle+0.02),
                     rer_z+0.0021+2*rib_r+0.0012)
    for ang in (-1.0, -0.5, 0.0, 0.5, 1.0):
        a = rer_center_angle+ang*rer_half
        footprints.append((N[0]+0.0705*math.cos(a), N[1]+0.0705*math.sin(a), 0.020))

    # Golgi: cuatro cisternas aplanadas y curvas (convexas hacia el núcleo), escalonadas en altura.
    g_dist = 0.112
    g_angle = math.radians(-36)
    rd = (math.cos(g_angle), math.sin(g_angle))
    G = (N[0]+g_dist*rd[0], N[1]+g_dist*rd[1])
    Rb = 0.045
    toward = math.atan2(-rd[1], -rd[0])
    golgi_meshes, buds = [], []
    specs = ((-0.01425, 0.019, 0.0045), (-0.00475, 0.024, 0.0030), (0.00475, 0.026, 0.0015), (0.01425, 0.024, 0.0))
    for off, half, dz in specs:
        r = Rb+off
        Cb = (G[0]+Rb*rd[0], G[1]+Rb*rd[1], z_top+0.0020+dz)
        sheet = FlattenedCisterna(radii=(half, 0.0040, 0.0017), wave=0.0007, center=(0, 0, 0))
        golgi_meshes.append(_map(sheet.mesh(segments=40, rings=8), lambda v, r=r, Cb=Cb: _bend(v, Cb, r, toward)))
        for sign in (-1, 1):
            buds.append(sphere((0.0026,)*3, center=_bend((sign*(half+0.0030), 0.0, 0.0), Cb, r, toward),
                               segments=10, rings=6))
    golgi = add('pila de Golgi', 'golgi', _merge(golgi_meshes), 'golgi')
    labels['golgi'] = _label_on(golgi_meshes[1])
    footprints.append((G[0], G[1], 0.032))

    # Vesículas: brotes en los extremos del Golgi, nube trans y algunas hacia la membrana.
    t = (-rd[1], rd[0])
    ves = list(buds)
    ves_pts = [(0.027, -0.018, 0.0040), (0.025, 0.0, 0.0042), (0.027, 0.018, 0.0038), (0.034, -0.009, 0.0034),
               (0.035, 0.010, 0.0036), (-0.021, 0.030, 0.0032), (-0.021, -0.030, 0.0032)]
    for u, w, r in ves_pts:
        x, y = G[0]+u*rd[0]+w*t[0], G[1]+u*rd[1]+w*t[1]
        ves.append(sphere((r,)*3, center=(x, y, zs(x, y)+0.0016), segments=10, rings=6))
        footprints.append((x, y, r+0.0005))
    for x, y, r in ((0.090, 0.028, 0.0042), (-0.012, -0.070, 0.0036), (0.112, -0.010, 0.0034),
                    (-0.060, 0.080, 0.0034)):
        ves.append(sphere((r,)*3, center=(x, y, zs(x, y)+0.0016), segments=10, rings=6))
        footprints.append((x, y, r+0.0005))
    add('vesiculas', 'vesiculas', _merge(ves), 'vesiculas')
    labels['vesiculas'] = _label_on(ves[9])

    # Mitocondrias: dos cerradas y una abierta con crestas interiores.
    for idx, (x, y, ang) in enumerate(((-0.100, 0.006, 80), (0.080, 0.050, -40))):
        m = _rot_z(sphere((0.020, 0.0090, 0.0088), segments=24, rings=12), math.radians(ang),
                   (x, y, z_top+0.0020))
        add(f'mitocondria cerrada {idx+1}', 'mitocondrias', m, 'mitocondrias')
        footprints.append((x, y, 0.021))
    mo = (0.014, -0.081)
    mo_ang = math.radians(6)
    mz = z_top+0.0025
    mr = (0.027, 0.0120, 0.0108)
    mprof = CutawayProfile(radii=mr, center=(0, 0, 0), cut_fraction=0.30, wall_fraction=0.12)
    m_shell = mprof.shell(segments=36, rings=10)
    m_matrix = mprof.fill(clearance=0.05, inset=0.30, segments=36, rings=10)
    m_top = mprof.cut_z-0.30*mr[2]
    ir = mprof.inner_radii
    cristae = []
    for n, cx in enumerate((-0.0190, -0.0127, -0.0064, 0.0, 0.0064, 0.0127, 0.0190)):
        w = ir[1]*math.sqrt(max(0.0, 1-(cx/ir[0])**2))
        lo_y, hi_y = -0.97*w, 0.30*w
        hy = (hi_y-lo_y)/2
        cy = (lo_y+hi_y)/2*(1 if n % 2 == 0 else -1)
        top = mprof.cut_z-0.0004
        hz = (top-(m_top-0.0025))/2
        cristae.append(sphere((0.00085, hy, hz), center=(cx, cy, top-hz), segments=12, rings=6))
    add('mitocondria abierta', 'mitocondrias', _place(m_shell, mo_ang, (mo[0], mo[1], mz)), 'mitocondrias')
    add('matriz mitocondrial', 'mitocondrias', _place(m_matrix, mo_ang, (mo[0], mo[1], mz)), 'matriz')
    crest = add('crestas', 'mitocondrias', _place(_merge(cristae), mo_ang, (mo[0], mo[1], mz)), 'crestas')
    labels['mitocondrias'] = _label_on(_place(cristae[3], mo_ang, (mo[0], mo[1], mz)), lift=0.0012)
    footprints.append((mo[0], mo[1], 0.028))

    # Lisosomas: tres esferas oscuras de tamaño variable.
    lys = []
    for x, y, r in ((-0.080, 0.062, 0.0085), (0.098, 0.004, 0.0095), (-0.026, -0.090, 0.0080)):
        lys.append(sphere((r,)*3, center=(x, y, zs(x, y)+0.0035), segments=16, rings=10))
        footprints.append((x, y, r))
    add('lisosomas', 'lisosomas', _merge(lys), 'lisosomas')
    labels['lisosomas'] = _label_on(lys[1])

    # REL: red tubular anastomosada sin ribosomas, a continuación del extremo del RER.
    zr = z_top+0.0016
    rel_paths = [
        [(-0.048, -0.050, zr), (-0.062, -0.057, zr), (-0.077, -0.050, zr), (-0.091, -0.038, zr)],
        [(-0.054, -0.068, zr), (-0.068, -0.073, zr), (-0.081, -0.064, zr), (-0.077, -0.050, zr)],
        [(-0.062, -0.057, zr), (-0.066, -0.066, zr), (-0.068, -0.073, zr)],
        [(-0.091, -0.038, zr), (-0.097, -0.052, zr), (-0.090, -0.064, zr), (-0.081, -0.064, zr)],
    ]
    rel_meshes = [tube(p, 0.0030, sides=8, steps=6) for p in rel_paths]
    add('tubos REL', 'rel', _merge(rel_meshes), 'rel')
    labels['rel'] = _label_on(rel_meshes[0])
    footprints.append((-0.072, -0.057, 0.030))

    # Centrosoma: matriz pericentriolar y dos centríolos perpendiculares de nueve túbulos.
    ca = math.radians(38)
    C = (N[0]+0.066*math.cos(ca), N[1]+0.066*math.sin(ca))
    zc0 = zs(C[0], C[1])
    add('matriz pericentriolar', 'centrosoma',
        sphere((0.0125, 0.0115, 0.0022), center=(C[0], C[1], zc0+0.0006), segments=20, rings=8), 'pericentriolar')
    rods = []
    ring_r, rod_r, half_len = 0.0046, 0.00105, 0.0085
    # Centríolo A: eje vertical (se ve de frente como un anillo de nueve túbulos).
    ax = (C[0]+0.0040, C[1]-0.0030)
    for i in range(9):
        a = math.tau*i/9
        p = (ax[0]+ring_r*math.cos(a), ax[1]+ring_r*math.sin(a))
        rods.append(tube([(p[0], p[1], zc0+0.0010), (p[0], p[1], zc0+0.0010+2*half_len)], rod_r, sides=6))
    # Centríolo B: eje horizontal perpendicular, tendido junto al A.
    bdir = (math.cos(ca+math.pi/2), math.sin(ca+math.pi/2))
    bc = (C[0]-0.0060, C[1]+0.0020, zc0+0.0010+ring_r+rod_r)
    up = (0.0, 0.0, 1.0)
    side = (bdir[1], -bdir[0], 0.0)
    for i in range(9):
        a = math.tau*i/9
        off = tuple(ring_r*(math.cos(a)*side[k]+math.sin(a)*up[k]) for k in range(3))
        p0 = (bc[0]-half_len*bdir[0]+off[0], bc[1]-half_len*bdir[1]+off[1], bc[2]+off[2])
        p1 = (bc[0]+half_len*bdir[0]+off[0], bc[1]+half_len*bdir[1]+off[1], bc[2]+off[2])
        rods.append(tube([p0, p1], rod_r, sides=6))
    add('centriolos', 'centrosoma', _merge(rods), 'centrosoma')
    labels['centrosoma'] = (ax[0], ax[1], zc0+0.0010+2*half_len+0.0020)
    footprints.append((C[0], C[1], 0.016))

    # Citoesqueleto: cuatro filamentos oscuros y escasos; sólo uno parte del centrosoma.
    zf = 0.0014

    def fpath(points):
        return [(x, y, zs(x, y)+zf) for x, y in points]
    cyto_paths = [
        fpath([(C[0]-0.010, C[1]+0.010), (-0.010, 0.087), (-0.035, 0.087), (-0.052, 0.080)]),
        fpath([(0.096, -0.020), (0.106, -0.040), (0.100, -0.058)]),
        fpath([(-0.105, 0.035), (-0.112, 0.020), (-0.114, -0.005)]),
        fpath([(0.002, -0.099), (-0.010, -0.101), (-0.022, -0.100)]),
    ]
    cyto = [tube(p, 0.0016, sides=6, steps=8) for p in cyto_paths]
    for p in cyto_paths:
        for q in _catmull(p, 8):
            footprints.append((q[0], q[1], 0.0025))
    add('filamentos', 'citoesqueleto', _merge(cyto), 'citoesqueleto')
    labels['citoesqueleto'] = _label_on(cyto[1])

    # Ribosomas libres: muestreo con rechazo en huecos del citosol (semilla del brief).
    free = []
    attempts = 0
    while len(free) < 28 and attempts < 8000:
        attempts += 1
        x = random.uniform(-fx, fx)
        y = random.uniform(-fy, fy)
        if not inside(x, y, 0.004, margin=0.92):
            continue
        if any((x-a)**2+(y-b)**2 < (r+0.004)**2 for a, b, r in footprints):
            continue
        if any((x-a)**2+(y-b)**2 < 0.009**2 for a, b in free):
            continue
        free.append((x, y))
    rib = list(bound)+[sphere((rib_r,)*3, center=(x, y, zs(x, y)+0.0010), segments=6, rings=4)
                       for x, y in free]
    add('ribosomas', 'ribosomas', _merge(rib), 'ribosomas')
    if free:
        labels['ribosomas'] = (free[0][0], free[0][1], zs(*free[0])+0.0010+rib_r+0.0015)
    else:
        labels['ribosomas'] = labels['rer']
    for x, y in free:
        footprints.append((x, y, 0.003))

    # Etiqueta del citoplasma: punto libre de la superficie del citosol.
    best, best_d = (0.0, -0.06), -1
    for i in range(-20, 21):
        for j in range(-20, 21):
            x, y = fx*i/21, fy*j/21
            if not inside(x, y, 0.0, margin=0.85):
                continue
            d = min(math.sqrt((x-a)**2+(y-b)**2)-r for a, b, r in footprints)
            if d > best_d:
                best, best_d = (x, y), d
    labels['citoplasma'] = (best[0], best[1], zs(*best)+0.0008)

    notes = [
        'Membrana como cuenco con labio continuo; corte inclinado 35° hacia arriba y al frente (-Y).',
        'Citosol pálido con relieve suave (±1.2 mm) contenido en la misma malla facetada; orgánulos medio hundidos.',
        'Núcleo con envoltura doble abierta (parcial), poros sugeridos en el labio y la cara externa, '
        'nucleoplasma, cromatina difusa y nucléolo sin membrana. Sin cromosomas en X.',
        'RER: tres cisternas aplanadas en arco junto al núcleo con ribosomas anclados a su superficie '
        '(anclajes de FlattenedCisterna en ángulos de la malla); ribosomas libres en el citosol.',
        'REL: red tubular anastomosada sin ribosomas, a continuación del RER.',
        'Golgi más alejado que el RER: cuatro cisternas aplanadas curvas, escalonadas, con vesículas en '
        'los extremos y en la cara trans; algunas vesículas hacia la membrana.',
        'Tres mitocondrias; una abierta muestra matriz y siete crestas interiores alternas.',
        'Centrosoma junto al núcleo: dos centríolos de nueve túbulos perpendiculares sobre matriz pericentriolar.',
        'Citoesqueleto escaso: cuatro filamentos oscuros; sólo uno parte del centrosoma.',
        'Escala uniforme a 0.30 m medida sobre vértices reales tras la inclinación; caja centrada en el origen.',
    ]
    return pieces, labels, notes


def _finalize(pieces, labels):
    c, s = math.cos(TILT), math.sin(TILT)

    def rot(v):
        return (v[0], c*v[1]-s*v[2], s*v[1]+c*v[2])

    rotated = [(n, p, _map(m, rot), mk, sm) for n, p, m, mk, sm in pieces]
    lo = [min(v[k] for _, _, m, _, _ in rotated for v in m.vertices) for k in range(3)]
    hi = [max(v[k] for _, _, m, _, _ in rotated for v in m.vertices) for k in range(3)]
    scale = TARGET/max(h-l for h, l in zip(hi, lo))
    mid = [(h+l)/2 for h, l in zip(hi, lo)]

    def place(v):
        return tuple(scale*(v[k]-mid[k]) for k in range(3))

    final = [(n, p, _map(m, place), mk, sm) for n, p, m, mk, sm in rotated]
    final_labels = {k: list(place(rot(v))) for k, v in labels.items()}
    return final, final_labels, scale


COLORS = {
    'membrana': ((0.85, 0.42, 0.36), 0.55),
    'citoplasma': ((0.74, 0.85, 0.78), 0.70),
    'nucleo': ((0.34, 0.18, 0.58), 0.50),
    'nucleoplasma': ((0.64, 0.54, 0.80), 0.60),
    'cromatina': ((0.42, 0.30, 0.62), 0.55),
    'poros': ((0.10, 0.04, 0.18), 0.45),
    'nucleolo': ((0.16, 0.03, 0.24), 0.50),
    'ribosomas': ((0.05, 0.06, 0.16), 0.45),
    'rer': ((0.18, 0.38, 0.82), 0.45),
    'rel': ((0.10, 0.62, 0.58), 0.45),
    'golgi': ((0.95, 0.68, 0.08), 0.45),
    'mitocondrias': ((0.90, 0.33, 0.10), 0.45),
    'matriz': ((0.98, 0.72, 0.52), 0.55),
    'crestas': ((0.55, 0.10, 0.04), 0.45),
    'lisosomas': ((0.55, 0.06, 0.14), 0.40),
    'vesiculas': ((1.00, 0.90, 0.45), 0.40),
    'centrosoma': ((0.12, 0.45, 0.10), 0.45),
    'pericentriolar': ((0.62, 0.84, 0.50), 0.60),
    'citoesqueleto': ((0.04, 0.045, 0.055), 0.50),
}


def build():
    pieces, labels, notes = layout()
    final, final_labels, _scale = _finalize(pieces, labels)
    mats = {key: material('Célula · '+key, col, roughness=rough) for key, (col, rough) in COLORS.items()}
    for name, part, mesh, mk, smooth in final:
        mesh_object(name, part, mesh, mats[mk], smooth=smooth)
    return {
        'title': 'Célula animal · corte abierto (detalle R1)',
        'design_notes': notes,
        'parts': {key: {'label_position': pos} for key, pos in final_labels.items()},
    }
