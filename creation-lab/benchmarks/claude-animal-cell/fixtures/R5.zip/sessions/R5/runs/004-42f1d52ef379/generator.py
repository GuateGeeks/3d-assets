"""Detalle v2 de la celula animal (replica R5, benchmark claude-animal-cell).

Correccion 2 sobre detail-v1 (feedback 003-4cc21c8cce0d): RER como cuatro
cisternas aplanadas y paralelas que rodean el lado derecho del nucleo, con
ribosomas pequenos en su cara externa; Golgi con cuatro cisternas
curvas de perfil; citoesqueleto como pocos filamentos curvos, mas
gruesos y oscuros, anclados a la membrana y sin atravesar organulos.
Mismos part_id que el blockout. Sin Blender en este generador: metros, Z
arriba, frente -Y.
"""
import math
import random

from components import CutawayProfile, FlattenedCisterna, material, mesh_object, sphere, validate_mesh
from components.geometry import MeshData

SEED = 20261022
TILT = math.radians(20.0)
SEG, RINGS = 32, 12
VIEW = (0.45, -0.60, 0.55)  # camara comun mirando al origen

MEMBRANE = CutawayProfile(radii=(0.150, 0.140, 0.110), center=(0.0, 0.0, 0.0),
                          cut_fraction=0.35, wall_fraction=0.08)
NUCLEUS = CutawayProfile(radii=(0.068, 0.062, 0.056), center=(-0.035, 0.025, -0.005),
                         cut_fraction=0.70, wall_fraction=0.08)
NUCLEOLUS = ((-0.035, 0.025, 0.022), (0.016, 0.016, 0.014))
# RER: cuatro cisternas aplanadas, paralelas, en arco alrededor del lado derecho del nucleo.
RER_R = 0.090
RER_ANGLE = -0.15
RER_Z = [0.006 + 0.009 * k for k in range(4)]
RER_HALF_LEN = 0.030
RER_HALF_W = 0.011
RER_THICK = 0.0045
RER_RIBOSOME_R = 0.0040
GOLGI_C = (0.050, 0.080, 0.020)
GOLGI_STEP = 0.0085
MITO_A = ((-0.075, -0.060, 0.015), (0.026, 0.015, 0.015))
MITO_B = ((0.085, -0.055, 0.015), (0.024, 0.015, 0.015))
CENTRO = (-0.070, 0.090, 0.020)
LYSOSOMES = [(-0.105, 0.020, 0.020), (-0.095, -0.030, 0.018), (-0.020, -0.040, 0.012)]
VESICLES = [(0.030, 0.060, 0.030), (0.060, 0.050, 0.032), (0.020, 0.102, 0.030),
            (0.080, 0.088, 0.030), (0.050, 0.040, 0.024)]
RIBOSOME_R = 0.0055
CYTO_SEED = SEED + 7
CYTO_R = 0.0020

MATERIALS = {
    "membrana": ("Detalle · membrana", (0.06, 0.35, 0.38), 0.50),
    "citosol": ("Detalle · citoplasma", (0.93, 0.90, 0.78), 0.80),
    "nucleo_env": ("Detalle · envoltura nuclear", (0.25, 0.35, 0.75), 0.50),
    "nucleo_fill": ("Detalle · nucleoplasma", (0.60, 0.66, 0.92), 0.65),
    "poro": ("Detalle · poros", (0.10, 0.12, 0.30), 0.40),
    "nucleolo": ("Detalle · nucleolo", (0.45, 0.20, 0.60), 0.60),
    "ribosoma": ("Detalle · ribosomas", (0.12, 0.12, 0.16), 0.60),
    "rer": ("Detalle · RER", (0.30, 0.70, 0.95), 0.50),
    "rel": ("Detalle · REL", (0.98, 0.80, 0.20), 0.55),
    "golgi": ("Detalle · Golgi", (0.95, 0.50, 0.70), 0.55),
    "vesicula": ("Detalle · vesiculas", (0.95, 0.95, 0.90), 0.45),
    "mito": ("Detalle · mitocondria", (0.85, 0.30, 0.10), 0.50),
    "crestas": ("Detalle · crestas", (0.55, 0.12, 0.05), 0.50),
    "lisosoma": ("Detalle · lisosomas", (0.35, 0.15, 0.55), 0.45),
    "centriolo": ("Detalle · centriolos", (0.95, 0.10, 0.45), 0.40),
    "citoesqueleto": ("Detalle · citoesqueleto", (0.20, 0.22, 0.30), 0.60),
}

PART_IDS = ["membrana", "citoplasma", "nucleo", "nucleolo", "ribosomas", "rer", "rel",
            "golgi", "mitocondrias", "lisosomas", "centrosoma", "vesiculas", "citoesqueleto"]

DESIGN_NOTES = [
    "Detalle v2 (R5): cuenco abierto por arriba con membrana sombreada en suave; corte inclinado 20 grados en X.",
    "Citoplasma palido con superficie superior a nivel del centro; zona palida como citosol.",
    "Nucleo con envoltura parcial en el cuenco nuclear, poros sugeridos en la cara frontal y nucleolo dentro, sin membrana propia.",
    "RER azul: cuatro cisternas aplanadas y paralelas que rodean el lado derecho del nucleo; ribosomas pequenos en su cara externa.",
    "REL tubular (red de tubos lisos) sin ribosomas adheridos.",
    "Golgi rosa curvo: pila de cuatro cisternas aplanadas vista de perfil, con vesiculas cercanas.",
    "Mitocondrias ovaladas; la B abierta muestra crestas internas. Dos mitocondrias en el esquema.",
    "Centrosoma magenta con dos centriolos cilindricos perpendiculares junto al nucleo; citoesqueleto escaso: tres filamentos curvos anclados a la membrana.",
    "Maqueta didactica, no escala microscopica exacta. Sin biologia aprobada; solo detalle.",
]


def _inside(p, center, radii):
    return sum(((p[k] - center[k]) / radii[k]) ** 2 for k in range(3)) <= 1.0


def _dist(a, b):
    return math.sqrt(sum((a[k] - b[k]) ** 2 for k in range(3)))


def _sub(a, b):
    return tuple(a[k] - b[k] for k in range(3))


def _unit(v):
    n = math.sqrt(sum(x * x for x in v))
    return tuple(x / n for x in v)


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def _merge(meshes):
    verts, faces = [], []
    for mesh in meshes:
        offset = len(verts)
        verts.extend(mesh.vertices)
        faces.extend(tuple(i + offset for i in face) for face in mesh.faces)
    return MeshData(tuple(verts), tuple(faces))


def _tilt(mesh):
    """Rotacion propia alrededor de X; conserva winding y dimension en X."""
    c, s = math.cos(TILT), math.sin(TILT)
    return MeshData(tuple((x, y * c - z * s, y * s + z * c) for x, y, z in mesh.vertices), mesh.faces)


def _tube(path, radius, sides=8):
    """Tubo cerrado a lo largo de una polilinea suave, con tapas planas en los extremos."""
    n = len(path)
    frames = []
    for i in range(n):
        a = path[max(i - 1, 0)]
        b = path[min(i + 1, n - 1)]
        t = _unit(_sub(b, a))
        ref = (0.0, 0.0, 1.0) if abs(t[2]) < 0.9 else (1.0, 0.0, 0.0)
        u = _unit(_cross(t, ref))
        v = _cross(t, u)
        frames.append((u, v))
    verts, faces = [], []
    for i, p in enumerate(path):
        u, v = frames[i]
        for k in range(sides):
            ang = math.tau * k / sides
            c, s = math.cos(ang), math.sin(ang)
            verts.append(tuple(p[j] + radius * (c * u[j] + s * v[j]) for j in range(3)))
    for i in range(n - 1):
        for k in range(sides):
            a0 = i * sides + k
            a1 = i * sides + (k + 1) % sides
            b0 = (i + 1) * sides + k
            b1 = (i + 1) * sides + (k + 1) % sides
            faces.append((a0, b0, b1))
            faces.append((a0, b1, a1))
    c0 = len(verts)
    verts.append(tuple(path[0]))
    for k in range(sides):
        faces.append((c0, k, (k + 1) % sides))
    base = (n - 1) * sides
    c1 = len(verts)
    verts.append(tuple(path[-1]))
    for k in range(sides):
        faces.append((c1, base + (k + 1) % sides, base + k))
    mesh = MeshData(tuple(verts), tuple(faces))
    if validate_mesh(mesh, closed=False)["signed_volume"] < 0:
        mesh = MeshData(mesh.vertices, tuple((f[0], f[2], f[1]) for f in mesh.faces))
    validate_mesh(mesh, closed=True)
    return mesh


def _rod(center, half_length, angle, radius=0.0022):
    rod = sphere((half_length, radius, radius), segments=8, rings=6)
    c, s = math.cos(angle), math.sin(angle)
    return MeshData(tuple((c * x - s * y + center[0], s * x + c * y + center[1], z + center[2])
                          for x, y, z in rod.vertices), rod.faces)


def _polar_to_nucleus(s_pos, z):
    """Mapea (s, n, z) de una cisterna del RER: s tangencial, n radial, a sobre el nucleo."""
    return s_pos, z


def _rer_map(mesh):
    """Curva una lamina aplanada (x=tangente, y=radial) en un arco de radio RER_R alrededor del nucleo."""
    cx, cy, _ = NUCLEUS.center
    verts = []
    for x, y, z in mesh.vertices:
        phi = x / RER_R
        r = RER_R + y
        ang = RER_ANGLE + phi
        verts.append((cx + r * math.cos(ang), cy + r * math.sin(ang), z))
    # El mapeo (s, n) -> (angulo, radio) invierte la orientacion: se reanudan los triangulos.
    return MeshData(tuple(verts), tuple((f[0], f[2], f[1]) for f in mesh.faces))


def _rer_stack():
    """Cuatro cisternas aplanadas y paralelas (distinta altura) y ribosomas en la cara externa."""
    cisterns, ribos = [], []
    base = FlattenedCisterna(radii=(RER_HALF_LEN, RER_HALF_W, RER_THICK), wave=0.0,
                             center=(0.0, 0.0, 0.0)).mesh(segments=20, rings=10)
    for z in RER_Z:
        shifted = tuple((x, y, zz + z) for x, y, zz in base.vertices)
        cisterns.append(_rer_map(MeshData(shifted, base.faces)))
        for phi in (-0.24, -0.12, 0.0, 0.12, 0.24):
            ang = RER_ANGLE + phi
            r = RER_R + RER_HALF_W + RIBOSOME_R * 0.6
            center = (NUCLEUS.center[0] + r * math.cos(ang), NUCLEUS.center[1] + r * math.sin(ang), z)
            ribos.append(sphere((RER_RIBOSOME_R,) * 3, center=center, segments=8, rings=5))
    return cisterns, ribos


def _golgi_plates():
    plates = []
    for k in range(4):
        sheet = FlattenedCisterna(radii=(0.026, 0.014, 0.0035), wave=0.0,
                                  center=(GOLGI_C[0] + 0.003 * k, GOLGI_C[1], GOLGI_C[2] + GOLGI_STEP * k)
                                  ).mesh(segments=24, rings=12)
        # Curvatura suave en el plano XY; la pila conserva el orden Z (vista de perfil).
        verts = []
        for x, y, z in sheet.vertices:
            th = (x - GOLGI_C[0]) / 0.05
            verts.append((x, y - 0.05 * (1.0 - math.cos(th)) + 0.0, z))
        plates.append(MeshData(tuple(verts), sheet.faces))
    return plates


def _cyto_filaments(count=3):
    """Filamentos curvos y escasos: arcos de Bezier con extremos sobre la pared interna."""
    rng = random.Random(CYTO_SEED)
    inner = MEMBRANE.inner_radii
    cavity = [r * 0.97 for r in inner]
    organelles = [(NUCLEUS.center, [r + 0.006 for r in NUCLEUS.radii]),
                  (NUCLEOLUS[0], [r + 0.006 for r in NUCLEOLUS[1]])]
    organelles += [(c, (0.017, 0.017, 0.017)) for c in LYSOSOMES]
    organelles += [(MITO_A[0], [r + 0.006 for r in MITO_A[1]]), (MITO_B[0], [r + 0.006 for r in MITO_B[1]]),
                   (GOLGI_C, (0.032, 0.020, 0.012)), (CENTRO, (0.024, 0.024, 0.026))]
    rel_path = [(-0.030 + 0.012 * k, -0.095 + 0.008 * math.sin(math.pi * k / 5.0), 0.020) for k in range(12)]
    accepted, all_samples = [], []
    for _ in range(40000):
        if len(accepted) >= count:
            break
        z0, z1 = rng.uniform(0.018, 0.030), rng.uniform(0.018, 0.030)
        t0, t1 = rng.uniform(0, math.tau), rng.uniform(0, math.tau)
        p0 = (inner[0] * math.cos(t0) * 0.85, inner[1] * math.sin(t0) * 0.85, z0)
        p1 = (inner[0] * math.cos(t1) * 0.85, inner[1] * math.sin(t1) * 0.85, z1)
        ctrl = (rng.uniform(-0.08, 0.08), rng.uniform(-0.08, 0.08), rng.uniform(0.02, 0.03))
        path = []
        for i in range(11):
            u = i / 10.0
            path.append(tuple((1 - u) ** 2 * p0[j] + 2 * (1 - u) * u * ctrl[j] + u * u * p1[j] for j in range(3)))
        ok = True
        for p in path:
            if not _inside(p, (0.0, 0.0, 0.0), cavity):
                ok = False
                break
            if any(_inside(p, c, r) for c, r in organelles):
                ok = False
                break
            if any(_dist(p, q) < 0.012 for q in rel_path):
                ok = False
                break
            if _dist(p, (NUCLEUS.center[0], NUCLEUS.center[1], p[2])) < 0.085 and p[2] < 0.045:
                ok = False  # zona del RER
                break
        if not ok:
            continue
        if any(_dist(p, q) < 0.014 for prev in all_samples for p in path[::2] for q in [prev]):
            continue
        accepted.append(path)
        all_samples.append(path[len(path) // 2])
    if len(accepted) < count:
        raise RuntimeError("no se encontraron filamentos sin cruzar organulos")
    return [_tube(path, CYTO_R, sides=6) for path in accepted]


def _nucleus_pores():
    """Poros sugeridos: pequenas cuentas oscuras sobre la envoltura nuclear, cara frontal."""
    a, b, c = NUCLEUS.radii
    cx, cy, cz = NUCLEUS.center
    pores = []
    for theta in (1.05, 1.25):
        for phi in (-2.3, -1.9, -1.5, -1.1, -0.7):
            x, y, z = a * math.sin(theta) * math.cos(phi), b * math.sin(theta) * math.sin(phi), c * math.cos(theta)
            n = _unit((x / (a * a), y / (b * b), z / (c * c)))
            p = (cx + x + 0.0008 * n[0], cy + y + 0.0008 * n[1], cz + z + 0.0008 * n[2])
            pores.append(sphere((0.0030, 0.0030, 0.0018), center=p, segments=8, rings=4))
    return pores


def _free_ribosome_centers(count):
    rng = random.Random(SEED)
    inner = [r * 0.85 for r in MEMBRANE.inner_radii]
    avoid = [(MITO_A[0], 0.030), (MITO_B[0], 0.030), (GOLGI_C, 0.035), (CENTRO, 0.030),
             (NUCLEOLUS[0], 0.030)] + [(c, 0.025) for c in LYSOSOMES] + [(c, 0.015) for c in VESICLES]
    out = []
    for _ in range(50000):
        if len(out) >= count:
            break
        p = (rng.uniform(-0.13, 0.13), rng.uniform(-0.13, 0.13), rng.uniform(0.006, 0.032))
        if not _inside(p, (0.0, 0.0, 0.0), [inner[0], inner[1], inner[2] * 2.0]):
            continue
        if _inside(p, NUCLEUS.center, [r * 1.15 for r in NUCLEUS.radii]):
            continue
        rr = _dist((p[0], p[1], 0.0), (NUCLEUS.center[0], NUCLEUS.center[1], 0.0))
        if RER_R - 0.03 < rr < RER_R + 0.03 and p[2] < 0.045:
            continue
        if any(_dist(p, c) < d for c, d in avoid):
            continue
        if any(_dist(p, q) < 0.014 for q in out):
            continue
        out.append(p)
    return out


def plan_blockout_detail():
    """Devuelve mallas finales (nombre, part_id, MeshData, material, smooth) y etiquetas."""
    items = []

    items.append(("membrana", "membrana", MEMBRANE.shell(segments=SEG, rings=RINGS), "membrana", True))
    items.append(("citoplasma", "citoplasma",
                  MEMBRANE.fill(clearance=0.03, inset=0.35, segments=SEG, rings=RINGS), "citosol", True))

    items.append(("nucleo envoltura", "nucleo", NUCLEUS.shell(segments=SEG, rings=RINGS), "nucleo_env", True))
    items.append(("nucleo nucleoplasma", "nucleo",
                  NUCLEUS.fill(clearance=0.04, inset=0.24, segments=SEG, rings=RINGS), "nucleo_fill", True))
    items.append(("poros nucleares", "nucleo", _merge(_nucleus_pores()), "poro", True))
    items.append(("nucleolo", "nucleolo", sphere(NUCLEOLUS[1], center=NUCLEOLUS[0], segments=16, rings=8),
                  "nucleolo", True))

    cisterns, rer_ribos = _rer_stack()
    for k, mesh in enumerate(cisterns):
        items.append((f"RER cisterna {k + 1}", "rer", mesh, "rer", True))

    free = _free_ribosome_centers(16)
    ribos = [sphere((RIBOSOME_R,) * 3, center=c, segments=8, rings=5) for c in free]
    items.append(("ribosomas", "ribosomas", _merge(ribos + rer_ribos), "ribosoma", True))

    rel_main = [(-0.030 + 0.012 * k, -0.095 + 0.008 * math.sin(math.pi * k / 5.0), 0.020) for k in range(12)]
    rel_branch = [(0.030 + 0.004 * k, -0.100 + 0.004 * k, 0.020 + 0.002 * k) for k in range(5)]
    items.append(("REL tubo principal", "rel",
                  _merge([_tube(rel_main, 0.0060, sides=8), _tube(rel_branch, 0.0045, sides=8)]),
                  "rel", True))

    items.append(("Golgi pila curva", "golgi", _merge(_golgi_plates()), "golgi", True))

    items.append(("mitocondria A cerrada", "mitocondrias",
                  sphere(MITO_A[1], center=MITO_A[0], segments=16, rings=8), "mito", True))
    b_center, b_radii = MITO_B
    mito_b_shell = CutawayProfile(radii=b_radii, center=b_center, cut_fraction=0.50,
                                  wall_fraction=0.12).shell(segments=16, rings=8)
    crests = [sphere((0.0014, 0.0100, 0.0070), center=(b_center[0] + dx, b_center[1], b_center[2] - 0.002),
                     segments=10, rings=6) for dx in (-0.010, -0.005, 0.0, 0.005, 0.010)]
    items.append(("mitocondria B abierta", "mitocondrias", mito_b_shell, "mito", True))
    items.append(("mitocondria B crestas", "mitocondrias", _merge(crests), "crestas", True))

    items.append(("lisosomas", "lisosomas",
                  _merge([sphere((0.011, 0.011, 0.011), center=c, segments=12, rings=6) for c in LYSOSOMES]),
                  "lisosoma", True))

    centrioles = [
        _tube([(CENTRO[0], CENTRO[1], CENTRO[2] - 0.020), (CENTRO[0], CENTRO[1], CENTRO[2] + 0.020)],
              0.0055, sides=10),
        _tube([(CENTRO[0] - 0.018, CENTRO[1] + 0.012, CENTRO[2]), (CENTRO[0] + 0.018, CENTRO[1] + 0.012, CENTRO[2])],
              0.0055, sides=10),
    ]
    items.append(("centriolos", "centrosoma", _merge(centrioles), "centriolo", True))

    items.append(("vesiculas", "vesiculas",
                  _merge([sphere((0.0065, 0.0065, 0.0065), center=c, segments=10, rings=6) for c in VESICLES]),
                  "vesicula", True))

    items.append(("citoesqueleto filamentos", "citoesqueleto", _merge(_cyto_filaments(3)), "citoesqueleto", True))

    # Inclinacion comun y etiquetas en el vertice mas visible de cada parte.
    norm = math.sqrt(sum(v * v for v in VIEW))
    view = tuple(v / norm for v in VIEW)
    final, by_part = [], {pid: [] for pid in PART_IDS}
    for name, part_id, mesh, mat_key, smooth in items:
        tilted = _tilt(mesh)
        final.append((name, part_id, tilted, mat_key, smooth))
        by_part[part_id].extend(tilted.vertices)
    parts = {}
    for pid in PART_IDS:
        best = max(by_part[pid], key=lambda v: sum(v[k] * view[k] for k in range(3)))
        parts[pid] = {"label_position": [round(best[k] + 0.006 * view[k], 5) for k in range(3)]}
    return {"meshes": final, "parts": parts, "title": "Celula animal · detalle v2 (R5)",
            "design_notes": DESIGN_NOTES}


def build():
    plan = plan_blockout_detail()
    mats = {key: material(name, color, roughness=rough) for key, (name, color, rough) in MATERIALS.items()}
    for name, part_id, mesh, mat_key, smooth in plan["meshes"]:
        mesh_object(name, part_id, mesh, mats[mat_key], smooth=smooth)
    return {"title": plan["title"], "design_notes": plan["design_notes"], "parts": plan["parts"]}
