"""Detalle v1 · célula animal (réplica R7). Primer detalle, sobre el blockout aprobado (v3).

Mantiene la envoltura, el citosol, la disposición y las 13 IDs del blockout v3 y añade:
- RER: tres cisternas aplanadas y onduladas, contiguas a la envoltura nuclear, con
  ribosomas anclados en su superficie (anclajes de components.FlattenedCisterna).
- Ribosomas libres repartidos en el citosol.
- REL: red tubular lisa y sin ribosomas (tubo principal y una rama).
- Golgi: pila de tres cisternas curvas (barridos en arco) con vesículas en la cara trans.
- Mitocondrias: una abierta con crestas interiores visibles y una cerrada.
- Núcleo: envoltura parcial (cúpula) con poros sugeridos, nucleoplasma de tono distinto
  y nucléolo.
- Dos centríolos aproximadamente perpendiculares, junto al núcleo.
- Citoesqueleto escaso: cuatro filamentos finos, sin rayos desde el centrosoma.

Sin E/S: el worker exporta y renderiza. Dimensión mayor normalizada a 0.30 m.
"""
import math
from components import CutawayProfile, FlattenedCisterna, MeshData, material, mesh_object, sphere, validate_mesh

LONGEST = 0.30
TILT = math.radians(50.0)
ENVELOPE = {"radii": (0.14, 0.11, 0.10), "cut_fraction": 0.30, "wall_fraction": 0.06}
CYTOSOL = {"clearance": 0.02, "inset": 0.12}
NUCLEUS = {"radii": (0.046, 0.040, 0.038), "center": (-0.035, 0.010, 0.012),
           "cut_fraction": 0.60, "wall_fraction": 0.10}
MAX_TRIANGLES = 45000

# clave: (id de parte, etiqueta, color lineal, rugosidad, sombreado suave)
STYLE = {
    "membrana": ("membrana", "Membrana plasmática", (0.06, 0.35, 0.38), 0.50, False),
    "citoplasma": ("citoplasma", "Citoplasma", (0.90, 0.88, 0.76), 0.65, False),
    "nuc_env": ("nucleo", "Envoltura nuclear", (0.30, 0.15, 0.50), 0.45, True),
    "nuc_int": ("nucleo", "Nucleoplasma", (0.56, 0.42, 0.76), 0.60, True),
    "nuc_pore": ("nucleo", "Poros nucleares", (0.10, 0.04, 0.18), 0.40, True),
    "nucleolo": ("nucleolo", "Nucléolo", (0.22, 0.07, 0.34), 0.50, True),
    "ribosoma": ("ribosomas", "Ribosomas", (0.15, 0.15, 0.18), 0.60, True),
    "rer": ("rer", "Retículo endoplasmático rugoso", (0.20, 0.45, 0.70), 0.45, True),
    "rel": ("rel", "Retículo endoplasmático liso", (0.55, 0.85, 0.40), 0.45, True),
    "golgi": ("golgi", "Aparato de Golgi", (0.92, 0.55, 0.20), 0.45, True),
    "vesicula": ("vesiculas", "Vesículas", (0.95, 0.90, 0.97), 0.50, True),
    "mito_out": ("mitocondrias", "Mitocondria (membrana)", (0.85, 0.25, 0.20), 0.45, True),
    "mito_cri": ("mitocondrias", "Crestas mitocondriales", (0.52, 0.10, 0.12), 0.40, True),
    "lisosoma": ("lisosomas", "Lisosomas", (0.10, 0.36, 0.12), 0.50, True),
    "centriolo": ("centrosoma", "Centríolos", (0.95, 0.85, 0.20), 0.50, True),
    "filamento": ("citoesqueleto", "Citoesqueleto", (0.55, 0.40, 0.25), 0.70, True),
}

NUCLEOLUS_CENTER = (-0.035, 0.010, 0.026)
NUCLEOLUS_RADIUS = 0.0075
FREE_RIBOSOMES = [(0.015, -0.012, 0.030), (-0.010, -0.010, 0.044), (-0.080, 0.045, 0.030),
                  (0.060, 0.040, 0.034)]
RIBOSOME_RADIUS = 0.0035
RER_SEGMENTS, RER_RINGS = 32, 12
RER_CISTERNAE = [  # centro, radios, ondulación
    ((-0.022, -0.037, 0.022), (0.040, 0.012, 0.0045), 0.003),
    ((-0.030, -0.038, 0.0315), (0.040, 0.012, 0.0045), 0.003),
    ((-0.016, -0.036, 0.041), (0.040, 0.012, 0.0045), 0.003),
]
REL_PATH = [(0.030, -0.060, 0.026), (0.070, -0.050, 0.030), (0.105, -0.020, 0.026)]
REL_BRANCH = [(0.070, -0.050, 0.030), (0.062, -0.072, 0.028), (0.055, -0.084, 0.026)]
REL_RADIUS = 0.0055
GOLGI_CENTER = (0.085, 0.020)
GOLGI_Z = (0.024, 0.0325, 0.041)
GOLGI_ARC_RADIUS = 0.040
VESICLE_BLOCKOUT = [(0.020, 0.040, 0.030), (0.030, -0.090, 0.026), (0.100, 0.050, 0.024)]
VESICLE_RADIUS = 0.0055
LYSOSOMES = [((0.045, -0.015, 0.032), 0.012), ((-0.010, -0.088, 0.030), 0.012)]
MITO_OPEN = {"center": (-0.093, -0.045, 0.028), "radii": (0.020, 0.012, 0.012),
             "cut_fraction": 0.35, "wall_fraction": 0.14}
MITO_CRISTA_Y = (-0.0055, -0.0018, 0.0018, 0.0055)
MITO_CLOSED = {"center": (0.045, 0.070, 0.026), "radii": (0.022, 0.012, 0.012)}
CENTRIOLE_A = [(0.005, 0.050, 0.0175), (0.005, 0.050, 0.026), (0.005, 0.050, 0.0345)]
CENTRIOLE_B = [(-0.006, 0.058, 0.025), (0.005, 0.058, 0.025), (0.016, 0.058, 0.025)]
CENTRIOLE_RADIUS = 0.0032
FILAMENTS = [
    [(0.060, -0.030, 0.026), (0.075, -0.030, 0.027), (0.090, -0.025, 0.028)],
    [(-0.100, 0.020, 0.024), (-0.105, -0.005, 0.026), (-0.100, -0.020, 0.028)],
    [(-0.050, 0.085, 0.024), (-0.020, 0.088, 0.026), (0.010, 0.086, 0.026)],
    [(-0.065, -0.075, 0.026), (-0.052, -0.078, 0.027), (-0.040, -0.080, 0.027)],
]
FILAMENT_RADIUS = 0.0018


def _combine(meshes):
    vertices, faces = [], []
    for mesh in meshes:
        offset = len(vertices)
        vertices.extend(mesh.vertices)
        faces.extend(tuple(i + offset for i in face) for face in mesh.faces)
    return MeshData(tuple(vertices), tuple(faces))


def _sweep(path, rw, rh=None, sides=16, subdivide=3):
    """Closed tube along a Catmull-Rom smoothed polyline; rw wide, rh thick (elliptic section)."""
    if rh is None:
        rh = rw

    def norm(v):
        n = math.sqrt(sum(c * c for c in v))
        return tuple(c / n for c in v)

    def cross(a, b):
        return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])

    dense = []
    n = len(path)
    for k in range(n - 1):
        p0, p1 = path[max(k - 1, 0)], path[k]
        p2, p3 = path[k + 1], path[min(k + 2, n - 1)]
        for s in range(subdivide):
            t = s / subdivide
            t2, t3 = t * t, t * t * t
            dense.append(tuple(0.5 * ((2 * p1[i]) + (-p0[i] + p2[i]) * t
                                     + (2 * p0[i] - 5 * p1[i] + 4 * p2[i] - p3[i]) * t2
                                     + (-p0[i] + 3 * p1[i] - 3 * p2[i] + p3[i]) * t3) for i in range(3)))
    dense.append(tuple(path[-1]))
    rings = []
    for k, p in enumerate(dense):
        a = dense[max(k - 1, 0)]
        b = dense[min(k + 1, len(dense) - 1)]
        t = norm(tuple(b[i] - a[i] for i in range(3)))
        ref = (0.0, 0.0, 1.0) if abs(t[2]) < 0.9 else (0.0, 1.0, 0.0)
        nv = norm(cross(t, ref))
        bn = norm(cross(t, nv))
        ring = []
        for s in range(sides):
            ang = math.tau * s / sides
            ring.append(tuple(p[i] + rw * math.cos(ang) * nv[i] + rh * math.sin(ang) * bn[i]
                              for i in range(3)))
        rings.append(ring)
    vertices, faces = [], []
    for ring in rings:
        vertices.extend(ring)
    start = 0
    cap0, cap1 = len(vertices), len(vertices) + 1
    vertices.append(tuple(dense[0]))
    vertices.append(tuple(dense[-1]))
    for k in range(len(rings) - 1):
        a, b = start + k * sides, start + (k + 1) * sides
        for s in range(sides):
            nxt = (s + 1) % sides
            faces.append((a + s, b + s, b + nxt))
            faces.append((a + s, b + nxt, a + nxt))
    last = start + (len(rings) - 1) * sides
    for s in range(sides):
        nxt = (s + 1) % sides
        faces.append((cap0, start + s, start + nxt))
        faces.append((cap1, last + nxt, last + s))
    mesh = MeshData(tuple(vertices), tuple(faces))
    if validate_mesh(mesh, closed=False)["signed_volume"] < 0:
        mesh = MeshData(mesh.vertices, tuple(tuple(reversed(f)) for f in faces))
    return mesh


def _ellipsoid_outer(center, radii, theta, phi):
    """Point on an ellipsoid and its outward unit normal."""
    p = (center[0] + radii[0] * math.sin(theta) * math.cos(phi),
         center[1] + radii[1] * math.sin(theta) * math.sin(phi),
         center[2] + radii[2] * math.cos(theta))
    n = (math.sin(theta) * math.cos(phi) / radii[0], math.sin(theta) * math.sin(phi) / radii[1],
         math.cos(theta) / radii[2])
    length = math.sqrt(sum(c * c for c in n))
    return p, tuple(c / length for c in n)


def _parts_local():
    """Return list of (style_key, MeshData). A key may appear several times (several objects)."""
    out = []
    profile = CutawayProfile(**ENVELOPE)
    nprof = CutawayProfile(radii=NUCLEUS["radii"], center=NUCLEUS["center"],
                           cut_fraction=NUCLEUS["cut_fraction"], wall_fraction=NUCLEUS["wall_fraction"])
    nc, nr = NUCLEUS["center"], NUCLEUS["radii"]

    out.append(("membrana", profile.shell(segments=48, rings=20)))
    out.append(("citoplasma", profile.fill(clearance=CYTOSOL["clearance"], inset=CYTOSOL["inset"],
                                           segments=48, rings=20)))

    # Núcleo: envoltura parcial (cúpula abierta), nucleoplasma de tono distinto y poros.
    out.append(("nuc_env", nprof.shell(segments=40, rings=16)))
    out.append(("nuc_int", nprof.fill(clearance=0.05, inset=0.35, segments=40, rings=16)))
    pores = []
    cos_t = 0.40
    sin_t = math.sqrt(1 - cos_t * cos_t)
    for phi in (0.0, math.pi / 4, math.pi / 2, 3 * math.pi / 4, math.pi, 5 * math.pi / 4, 7 * math.pi / 4):
        theta = math.acos(cos_t)
        p, n = _ellipsoid_outer(nc, nr, theta, phi)
        center = tuple(p[i] + 0.0007 * n[i] for i in range(3))
        pores.append(sphere((0.0028, 0.0028, 0.0009), center=center, segments=10, rings=5))
    out.append(("nuc_pore", _combine(pores)))

    out.append(("nucleolo", _combine([
        sphere((NUCLEOLUS_RADIUS,) * 3, center=NUCLEOLUS_CENTER, segments=20, rings=10),
        sphere((0.0045,) * 3, center=(-0.040, 0.014, 0.024), segments=12, rings=6),
    ])))

    # RER: tres cisternas aplanadas; ribosomas anclados en la cara superior de la cisterna
    # superior y en el borde frontal de cada una (mismas segmentaciones que la malla).
    cisternae = [FlattenedCisterna(radii=r, wave=w, center=c) for c, r, w in RER_CISTERNAE]
    rer_meshes = [cis.mesh(segments=RER_SEGMENTS, rings=RER_RINGS) for cis in cisternae]
    out.append(("rer", _combine(rer_meshes)))
    anchored = []
    top = cisternae[-1]
    for j in (2, 3):
        for i in range(0, RER_SEGMENTS, 4):
            p, _n = top.anchor(math.pi * j / RER_RINGS, math.tau * i / RER_SEGMENTS, offset=RIBOSOME_RADIUS)
            anchored.append(p)
    for cis in cisternae:
        for i in (23, 24, 25):
            p, _n = cis.anchor(math.pi * 6 / RER_RINGS, math.tau * i / RER_SEGMENTS, offset=RIBOSOME_RADIUS)
            anchored.append(p)
    ribos = [sphere((RIBOSOME_RADIUS,) * 3, center=c, segments=10, rings=5) for c in anchored]
    ribos += [sphere((RIBOSOME_RADIUS,) * 3, center=c, segments=10, rings=5) for c in FREE_RIBOSOMES]
    out.append(("ribosoma", _combine(ribos)))

    # REL: tubo principal y rama, sin ribosomas.
    out.append(("rel", _combine([_sweep(REL_PATH, REL_RADIUS, sides=16, subdivide=4),
                                 _sweep(REL_BRANCH, REL_RADIUS * 0.8, sides=12, subdivide=4)])))

    # Golgi: tres cisternas curvas en arco con vesículas en la cara trans (convexa).
    gx, gy = GOLGI_CENTER
    arcs, budded = [], []
    for k, z in enumerate(GOLGI_Z):
        radius = GOLGI_ARC_RADIUS + 0.002 * k
        cx, cy = gx - radius, gy
        angles = [-0.55 + 1.1 * s / 6 for s in range(7)]
        arc = [(cx + radius * math.cos(a), cy + radius * math.sin(a), z) for a in angles]
        arcs.append(_sweep(arc, 0.0068, 0.0026, sides=12, subdivide=2))
        for a in (-0.6, 0.6):
            budded.append(sphere((0.0045,) * 3, center=(cx + (radius + 0.012) * math.cos(a),
                                                        cy + (radius + 0.012) * math.sin(a), z + 0.004),
                                 segments=10, rings=5))
    out.append(("golgi", _combine(arcs)))

    # Vesículas: cerca del Golgi y dispersas en el citosol.
    vesicles = [sphere((VESICLE_RADIUS,) * 3, center=c, segments=10, rings=5) for c in
                [(0.088, 0.060, 0.026)]] + budded
    vesicles += [sphere((0.006,) * 3, center=c, segments=12, rings=6) for c in VESICLE_BLOCKOUT]
    out.append(("vesicula", _combine(vesicles)))

    # Mitocondria abierta con crestas interiores; mitocondria cerrada.
    mo = MITO_OPEN
    mito_profile = CutawayProfile(radii=mo["radii"], center=mo["center"],
                                  cut_fraction=mo["cut_fraction"], wall_fraction=mo["wall_fraction"])
    out.append(("mito_out", mito_profile.shell(segments=28, rings=12)))
    cx, cy, cz = mo["center"]
    cristae = [sphere((0.0125, 0.0010, 0.0060), center=(cx, cy + dy, cz - 0.002), segments=12, rings=6)
               for dy in MITO_CRISTA_Y]
    out.append(("mito_cri", _combine(cristae)))
    mc = MITO_CLOSED
    out.append(("mito_out", sphere(mc["radii"], center=mc["center"], segments=24, rings=12)))

    # Lisosomas.
    out.append(("lisosoma", _combine([sphere((r,) * 3, center=c, segments=14, rings=7) for c, r in LYSOSOMES])))

    # Centrosoma: dos centríolos (tubos cortos) aproximadamente perpendiculares.
    out.append(("centriolo", _combine([
        _sweep(CENTRIOLE_A, CENTRIOLE_RADIUS, sides=12, subdivide=2),
        _sweep(CENTRIOLE_B, CENTRIOLE_RADIUS, sides=12, subdivide=2),
    ])))

    # Citoesqueleto escaso: cuatro filamentos finos.
    out.append(("filamento", _combine([_sweep(f, FILAMENT_RADIUS, sides=8, subdivide=2) for f in FILAMENTS])))
    return out


def _tilt(p):
    x, y, z = p
    c, s = math.cos(TILT), math.sin(TILT)
    return (x, y * c - z * s, y * s + z * c)


def _compose():
    """Return (list of (key, final MeshData), place function, local list)."""
    local = _parts_local()
    tilted = [(k, MeshData(tuple(_tilt(v) for v in m.vertices), m.faces)) for k, m in local]
    everything = [v for _k, m in tilted for v in m.vertices]
    lo = [min(v[i] for v in everything) for i in range(3)]
    hi = [max(v[i] for v in everything) for i in range(3)]
    center = [(lo[i] + hi[i]) / 2 for i in range(3)]
    longest = max(hi[i] - lo[i] for i in range(3))
    scale = LONGEST / longest

    def place(p):
        return tuple(float(scale * (p[i] - center[i])) for i in range(3))

    final = [(k, MeshData(tuple(place(v) for v in m.vertices), m.faces)) for k, m in tilted]
    return final, place, local


def build():
    final, _place, _local = _compose()
    for index, (key, mesh) in enumerate(final):
        part_id, label, color, roughness, smooth = STYLE[key]
        mat = material(label, color, roughness=roughness)
        mesh_object(f"{label} {index:02d}", part_id, mesh, mat, smooth=smooth, max_triangles=MAX_TRIANGLES)

    tops = {}
    for key, mesh in final:
        part_id = STYLE[key][0]
        top = max(mesh.vertices, key=lambda v: v[2])
        if part_id not in tops or top[2] > tops[part_id][2]:
            tops[part_id] = top
    parts = {pid: {"label_position": [float(t[0]), float(t[1]), float(t[2])]} for pid, t in tops.items()}

    return {
        "title": "Célula animal · detalle v1 (R7)",
        "design_notes": [
            "Envoltura abierta hacia el frente y arriba; citosol pálido con orgánulos sobre su superficie.",
            "RER de tres cisternas onduladas junto al núcleo, con ribosomas anclados en su superficie.",
            "REL tubular liso con una rama, sin ribosomas.",
            "Golgi en pila de tres cisternas curvas con vesículas en la cara trans.",
            "Mitocondria abierta con crestas interiores y mitocondria cerrada.",
            "Núcleo con envoltura parcial, poros sugeridos y nucléolo; dos centríolos junto al núcleo.",
            "Citoesqueleto escaso. Maqueta didáctica de 0.30 m; no es una escala microscópica exacta.",
        ],
        "parts": parts,
    }
