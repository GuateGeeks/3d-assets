"""Animal cell blockout (R3). Opened shell, pool cytoplasm, 13 separated parts.

Z up, front -Y. Shell is opened on top and tilted open toward the front.
No file I/O, lights, cameras or export: the worker does that.
"""
import math
import random
from components import (CutawayProfile, FlattenedCisterna, MeshData, sphere,
                        material, mesh_object)

LS = 0.93  # footprint scale applied to organelle xy positions only


def pm(x, y):
    return (x*LS, y*LS)


def xf(mesh, bend=0.0, rot=0.0, move=(0, 0, 0)):
    c, s = math.cos(rot), math.sin(rot)
    out = []
    for x, y, z in mesh.vertices:
        z = z+bend*x*x
        out.append((c*x-s*y+move[0], s*x+c*y+move[1], z+move[2]))
    return MeshData(tuple(out), mesh.faces)


def xf_point(p, bend=0.0, rot=0.0, move=(0, 0, 0)):
    return xf(MeshData((tuple(p),), ()), bend, rot, move).vertices[0]


def merge(meshes):
    verts, faces = [], []
    for m in meshes:
        o = len(verts)
        verts.extend(m.vertices)
        faces.extend(tuple(i+o for i in f) for f in m.faces)
    return MeshData(tuple(verts), tuple(faces))


def nearest(mesh, target):
    return min(mesh.vertices, key=lambda v: sum((a-b)**2 for a, b in zip(v, target)))


def tube(points, radius, sides=8):
    """Closed capped tube along a polyline, outward winding."""
    n = len(points)
    tans = []
    for k in range(n):
        a = points[max(k-1, 0)]
        b = points[min(k+1, n-1)]
        d = [b[i]-a[i] for i in range(3)]
        L = math.sqrt(sum(x*x for x in d))
        tans.append(tuple(x/L for x in d))
    t0 = tans[0]
    helper = (0, 0, 1) if abs(t0[2]) < 0.9 else (1, 0, 0)
    nrm = [t0[1]*helper[2]-t0[2]*helper[1], t0[2]*helper[0]-t0[0]*helper[2],
           t0[0]*helper[1]-t0[1]*helper[0]]
    L = math.sqrt(sum(x*x for x in nrm))
    nrm = [x/L for x in nrm]
    verts, faces = [], []
    for k in range(n):
        t = tans[k]
        dot = sum(nrm[i]*t[i] for i in range(3))
        nrm = [nrm[i]-dot*t[i] for i in range(3)]
        L = math.sqrt(sum(x*x for x in nrm))
        nrm = [x/L for x in nrm]
        b = (t[1]*nrm[2]-t[2]*nrm[1], t[2]*nrm[0]-t[0]*nrm[2], t[0]*nrm[1]-t[1]*nrm[0])
        for i in range(sides):
            ang = math.tau*i/sides
            ca, sa = math.cos(ang)*radius, math.sin(ang)*radius
            verts.append(tuple(points[k][j]+ca*nrm[j]+sa*b[j] for j in range(3)))
    for k in range(n-1):
        for i in range(sides):
            j = (i+1) % sides
            a0, a1, b0, b1 = k*sides+i, k*sides+j, (k+1)*sides+i, (k+1)*sides+j
            faces.extend(((a0, a1, b1), (a0, b1, b0)))
    c0 = len(verts)
    verts.append(tuple(points[0]))
    c1 = len(verts)
    verts.append(tuple(points[-1]))
    for i in range(sides):
        j = (i+1) % sides
        faces.append((c0, j, i))
        faces.append((c1, (n-1)*sides+i, (n-1)*sides+j))
    return MeshData(tuple(verts), tuple(faces))


def torus(R, r, seg=12, tseg=6):
    verts, faces = [], []
    for i in range(seg):
        u = math.tau*i/seg
        for j in range(tseg):
            v = math.tau*j/tseg
            verts.append(((R+r*math.cos(v))*math.cos(u), (R+r*math.cos(v))*math.sin(u), r*math.sin(v)))
    for i in range(seg):
        for j in range(tseg):
            a = i*tseg+j
            b = ((i+1) % seg)*tseg+j
            c = ((i+1) % seg)*tseg+(j+1) % tseg
            d = i*tseg+(j+1) % tseg
            faces.extend(((a, b, c), (a, c, d)))
    return MeshData(tuple(verts), tuple(faces))


def orient(mesh, normal, origin):
    n = normal
    L = math.sqrt(sum(x*x for x in n))
    n = [x/L for x in n]
    h = (0, 0, 1) if abs(n[2]) < 0.9 else (1, 0, 0)
    u1 = [n[1]*h[2]-n[2]*h[1], n[2]*h[0]-n[0]*h[2], n[0]*h[1]-n[1]*h[0]]
    L = math.sqrt(sum(x*x for x in u1))
    u1 = [x/L for x in u1]
    u2 = [n[1]*u1[2]-n[2]*u1[1], n[2]*u1[0]-n[0]*u1[2], n[0]*u1[1]-n[1]*u1[0]]
    out = []
    for x, y, z in mesh.vertices:
        out.append(tuple(origin[k]+x*u1[k]+y*u2[k]+z*n[k] for k in range(3)))
    return MeshData(tuple(out), mesh.faces)


def centriole(c, axis, half, zc):
    def pt(s, a, z):
        return (c[0]+s, c[1]+a, zc+z) if axis == 'x' else (c[0]+a, c[1]+s, zc+z)
    parts = [tube([pt(-half*0.97, 0, 0), pt(half*0.97, 0, 0)], 0.0030, 12)]
    for i in range(9):
        ang = math.tau*i/9
        parts.append(tube([pt(-half, 0.0036*math.cos(ang), 0.0036*math.sin(ang)),
                           pt(half, 0.0036*math.cos(ang), 0.0036*math.sin(ang))], 0.0012, 6))
    return merge(parts)


def wave_path(a, b, z, amp, waves, n=14, phase=0.0):
    dx, dy = b[0]-a[0], b[1]-a[1]
    L = math.hypot(dx, dy)
    px, py = -dy/L, dx/L
    pts = []
    for k in range(n):
        u = k/(n-1)
        w = amp*math.sin(math.tau*waves*u+phase)
        pts.append((a[0]+dx*u+px*w, a[1]+dy*u+py*w, z))
    return pts


def build():
    # ---- envelope: scale rx so the real vertex x-extent is 0.300 m -------
    SEG, RNG, WALL, CUT = 48, 16, 0.04, 0.25
    r0 = (0.15, 0.125, 0.115)
    m0 = CutawayProfile(radii=r0, cut_fraction=CUT, wall_fraction=WALL).shell(segments=SEG, rings=RNG)
    ext0 = max(v[0] for v in m0.vertices)-min(v[0] for v in m0.vertices)
    radii = (r0[0]*0.300/ext0, r0[1], r0[2])
    profile = CutawayProfile(radii=radii, cut_fraction=CUT, wall_fraction=WALL)
    inner = profile.inner_radii

    # ---- cytoplasm pool (shallow floor, organelles stand on it) ----------
    R2 = tuple(r*0.97 for r in inner)
    pool_cut = -0.0358
    pool_prof = CutawayProfile(radii=R2, cut_fraction=pool_cut/R2[2], wall_fraction=0.01)
    pool = pool_prof.fill(clearance=0.005, inset=0.01, segments=SEG, rings=RNG)
    ztop = max(v[2] for v in pool.vertices)

    # ---- shell opened toward the front by a tilted lip (shear above zlow)
    shell = profile.shell(segments=SEG, rings=RNG)
    zlow, zc, S = ztop+0.001, profile.cut_z, 0.50
    sv = []
    for x, y, z in shell.vertices:
        w = min(1.0, max(0.0, (z-zlow)/(zc-zlow)))
        sv.append((x, y, z+(S*y-0.03*(x/profile.radii[0])**2)*w))
    shell = MeshData(tuple(sv), shell.faces)

    M = {}
    def mat(key, color, rough=0.55):
        M[key] = material('Celula · '+key, color, roughness=rough)
        return M[key]
    mat('membrana', (0.80, 0.50, 0.30), 0.45)
    mat('citoplasma', (0.95, 0.88, 0.58), 0.7)
    mat('nucleo', (0.42, 0.28, 0.72), 0.5)
    mat('nucleoplasma', (0.66, 0.54, 0.90), 0.65)
    mat('nucleolo', (0.22, 0.06, 0.38), 0.5)
    mat('ribosomas', (0.04, 0.09, 0.32), 0.5)
    mat('rer', (0.12, 0.50, 0.78), 0.5)
    mat('rel', (0.08, 0.52, 0.33), 0.5)
    mat('golgi', (0.95, 0.66, 0.12), 0.45)
    mat('mito', (0.84, 0.16, 0.10), 0.5)
    mat('matriz', (0.96, 0.52, 0.38), 0.6)
    mat('crestas', (0.62, 0.04, 0.10), 0.5)
    mat('lisosomas', (0.80, 0.95, 0.0), 0.4)
    mat('vesiculas', (0.85, 0.08, 0.50), 0.4)
    mat('centrosoma', (0.05, 0.62, 0.58), 0.5)
    mat('poros', (0.16, 0.06, 0.36), 0.5)
    mat('citoesqueleto', (0.10, 0.10, 0.14), 0.5)

    parts = {}
    mesh_object('envoltura', 'membrana', shell, M['membrana'], smooth=False)
    mesh_object('piso citosol', 'citoplasma', pool, M['citoplasma'], smooth=False)
    rim_back = max(shell.vertices[:SEG], key=lambda v: v[1])
    parts['membrana'] = {'label_position': [rim_back[0], rim_back[1], rim_back[2]+0.002]}
    parts['citoplasma'] = {'label_position': [*pm(0.027, -0.047), ztop+0.001]}

    # ---- nucleus: open envelope + nucleoplasm + nucleolus ---------------
    nr = (0.055, 0.052, 0.048)
    nc = (*pm(-0.005, 0.015), ztop-0.010+nr[2])
    nprof = CutawayProfile(radii=nr, cut_fraction=0.5, wall_fraction=0.12, center=nc)
    nshell = nprof.shell(segments=40, rings=14)
    nfill = nprof.fill(clearance=0.02, inset=0.14, segments=40, rings=14)
    mesh_object('envoltura nuclear', 'nucleo', nshell, M['nucleo'], smooth=False)
    mesh_object('nucleoplasma', 'nucleo', nfill, M['nucleoplasma'], smooth=False)
    nftop = max(v[2] for v in nfill.vertices)
    lip = nearest(nshell, (nc[0]+0.04, nc[1]-0.04, nprof.cut_z))
    parts['nucleo'] = {'label_position': [lip[0], lip[1], lip[2]+0.002]}
    ncl_r = 0.011
    ncl_c = (nc[0]+0.008, nc[1]-0.006, nftop-0.0045+0.0)
    mesh_object('nucleolo', 'nucleolo',
                sphere((ncl_r,)*3, center=ncl_c, segments=20, rings=10), M['nucleolo'])
    parts['nucleolo'] = {'label_position': [ncl_c[0], ncl_c[1], ncl_c[2]+ncl_r]}

    pores = []
    for th in (72, 96):
        for ph in range(-110, 11, 20):
            t, p = math.radians(th), math.radians(ph)
            q = (nr[0]*math.sin(t)*math.cos(p), nr[1]*math.sin(t)*math.sin(p), nr[2]*math.cos(t))
            nrm = (q[0]/nr[0]**2, q[1]/nr[1]**2, q[2]/nr[2]**2)
            pores.append(orient(torus(0.0036, 0.0011), nrm, (nc[0]+q[0], nc[1]+q[1], nc[2]+q[2])))
    mesh_object('poros nucleares', 'nucleo', merge(pores), M['poros'], smooth=False)

    # ---- RER: three flattened cisternae next to the nucleus + ribosomes -
    rer_c = pm(-0.092, 0.025)
    rib_r = 0.0028
    rib_mesh = lambda c: sphere((rib_r,)*3, center=c, segments=10, rings=5)
    rer_sheets, bound = [], []
    for k, (rx, ry) in enumerate(((0.024, 0.020), (0.022, 0.018), (0.020, 0.016))):
        c = (rer_c[0]-0.002*k, rer_c[1]+0.003*k, ztop+0.004+0.012*k)
        sh = FlattenedCisterna(radii=(rx, ry, 0.0035), wave=0.0015, center=c)
        mesh_object(f'cisterna {k}', 'rer', sh.mesh(segments=24, rings=12), M['rer'])
        rer_sheets.append(sh)
        for j in (2, 3, 4):
            for i in range(0, 24, 3):
                a, _ = sh.anchor(math.pi*j/12, math.tau*i/24, offset=rib_r)
                bound.append(a)
    parts['rer'] = {'label_position': list(rer_sheets[-1].surface(math.pi*0.5, math.pi*1.25)[0])}
    parts['rer']['label_position'][2] += 0.001
    rng = random.Random(20261022)
    occupied = [(*nc[:2], 0.060), (*rer_c, 0.034), (*pm(0.08, 0.035), 0.040),
                (*pm(-0.10, -0.03), 0.030), (*pm(0.095, -0.03), 0.026),
                (*pm(0.04, -0.075), 0.030), (*pm(-0.058, -0.072), 0.026),
                (*pm(0.0, -0.065), 0.020), (*pm(0.0, -0.09), 0.012),
                (*pm(0.055, -0.03), 0.010), (*pm(-0.03, -0.047), 0.010),
                (*pm(-0.022, -0.088), 0.010), (*pm(0.085, 0.011), 0.030),
                (*pm(0.05, 0.06), 0.008), (*pm(0.065, 0.068), 0.008), (*pm(0.085, -0.003), 0.030),
                (*pm(0.06, -0.054), 0.030), (*pm(0.09, 0.075), 0.025)]
    ax = (R2[0]*0.84, R2[1]*0.84)
    free, tries = [], 0
    while len(free) < 30 and tries < 4000:
        tries += 1
        x, y = rng.uniform(-ax[0], ax[0]), rng.uniform(-ax[1], ax[1])
        if (x/(ax[0]*0.80))**2+(y/(ax[1]*0.80))**2 > 1:
            continue
        if any(math.hypot(x-ox, y-oy) < orr+0.008 for ox, oy, orr in occupied):
            continue
        if any(math.hypot(x-fx, y-fy) < 0.016 for fx, fy, _ in free):
            continue
        free.append((x, y, ztop+rib_r-0.0006))
    parts_rib = [rib_mesh(c) for c in bound]+[rib_mesh(c) for c in free]
    mesh_object('ribosomas', 'ribosomas', merge(parts_rib), M['ribosomas'])
    parts['ribosomas'] = {'label_position': [bound[0][0], bound[0][1], bound[0][2]+rib_r+0.001]}

    # ---- REL: three wavy tubes, no ribosomes ---------------------------
    rel_r = 0.0032
    zrel = ztop+rel_r-0.0008
    rel_mid = None
    rel_paths = []
    for k, (y0, ph) in enumerate(((-0.012, 0.0), (-0.030, 1.5), (-0.048, 3.0))):
        a, b = pm(-0.108, y0), pm(-0.074, y0)
        path = wave_path((a[0], a[1]), (b[0], b[1]), zrel, 0.004, 1.5, 14, ph)
        mesh_object(f'tubo {k}', 'rel', tube(path, rel_r, 8), M['rel'])
        rel_paths.append(path)
        if k == 1:
            rel_mid = path[7]
    for pa, pb, idx in ((0, 1, 4), (1, 2, 9), (0, 1, 11)):
        mesh_object(f'enlace {pa}{pb}{idx}', 'rel',
                    tube([rel_paths[pa][idx], rel_paths[pb][idx]], 0.0024, 8), M['rel'])
    parts['rel'] = {'label_position': [rel_mid[0], rel_mid[1], rel_mid[2]+rel_r+0.001]}

    # ---- Golgi: four curved stacked plates, farther from nucleus than RER
    g_c = pm(0.088, 0.033)
    g_rot = math.radians(20)
    g_top = None
    for k, rx in enumerate((0.030, 0.028, 0.026, 0.024)):
        plate = FlattenedCisterna(radii=(rx, 0.013, 0.0035), wave=0.0008, center=(0, 0, 0))
        zk = ztop+0.0045+0.0085*k
        mesh_object(f'cisterna golgi {k}', 'golgi', xf(plate.mesh(segments=24, rings=10), 6.0, g_rot, (*g_c, zk)), M['golgi'])
        g_top = xf_point((0, 0, 0.0035), 6.0, g_rot, (*g_c, zk))
    parts['golgi'] = {'label_position': [g_top[0], g_top[1], g_top[2]+0.001]}

    # ---- mitochondria: two closed + one open with cristae ---------------
    mr = (0.022, 0.0105, 0.0105)
    zm = ztop+mr[2]-0.002
    m1 = pm(0.095, -0.03)
    mesh_object('mitocondria 1', 'mitocondrias',
                xf(sphere(mr, segments=24, rings=12), 0, math.radians(20), (*m1, zm)), M['mito'])
    m3 = pm(-0.066, -0.072)
    mesh_object('mitocondria 3', 'mitocondrias',
                xf(sphere(mr, segments=24, rings=12), 0, math.radians(-15), (*m3, zm)), M['mito'])
    orr = (0.026, 0.0125, 0.0125)
    m2 = pm(0.04, -0.075)
    zo = ztop+orr[2]-0.002
    mprof = CutawayProfile(radii=orr, cut_fraction=0.15, wall_fraction=0.22)
    mesh_object('mitocondria abierta', 'mitocondrias',
                xf(mprof.shell(segments=28, rings=12), 0, 0, (*m2, zo)), M['mito'], smooth=False)
    mfill = mprof.fill(clearance=0.03, inset=0.45, segments=28, rings=12)
    mesh_object('matriz', 'mitocondrias', xf(mfill, 0, 0, (*m2, zo)), M['matriz'], smooth=False)
    crests = [sphere((0.0009, 0.0062, 0.0050), center=(cx, 0, -0.0033), segments=12, rings=6)
              for cx in (-0.012, -0.006, 0.0, 0.006, 0.012)]
    mesh_object('crestas', 'mitocondrias', xf(merge(crests), 0, 0, (*m2, zo)), M['crestas'])
    parts['mitocondrias'] = {'label_position': [m1[0], m1[1], zm+mr[2]+0.001]}

    # ---- lysosomes, vesicles --------------------------------------------
    lr = 0.0085
    lys = [pm(0.055, -0.030), pm(-0.030, -0.047), pm(-0.022, -0.088)]
    mesh_object('lisosomas', 'lisosomas',
                merge([sphere((lr,)*3, center=(*p, ztop+lr-0.001), segments=16, rings=8) for p in lys]),
                M['lisosomas'])
    parts['lisosomas'] = {'label_position': [lys[0][0], lys[0][1], ztop+2*lr]}
    vr = 0.0034
    ves = [pm(0.062, 0.014), pm(0.077, 0.009), pm(0.092, 0.009), pm(0.106, 0.014),
           pm(0.067, -0.002), pm(0.083, -0.005), pm(0.099, -0.002),
           pm(0.05, 0.06), pm(0.065, 0.068)]
    mesh_object('vesiculas', 'vesiculas',
                merge([sphere((vr,)*3, center=(*p, ztop+vr-0.0006), segments=12, rings=6) for p in ves]),
                M['vesiculas'])
    parts['vesiculas'] = {'label_position': [ves[2][0], ves[2][1], ztop+2*vr]}

    # ---- centrosome: two perpendicular centrioles near the nucleus ------
    cc = pm(0.0, -0.058)
    cr, half, zcn = 0.0048, 0.011, ztop+0.0048-0.001
    mesh_object('centriolo A', 'centrosoma', centriole((cc[0], cc[1]), 'x', half, zcn), M['centrosoma'])
    by = cc[1]-(cr+half+0.001)
    mesh_object('centriolo B', 'centrosoma', centriole((cc[0], by), 'y', half, zcn), M['centrosoma'])
    parts['centrosoma'] = {'label_position': [cc[0], cc[1], zcn+cr+0.001]}

    # ---- cytoskeleton: a few sparse cortical filaments ------------------
    fr = 0.0034
    zf = ztop+fr-0.0004
    fil = [([pm(0.112, -0.052), pm(0.10, -0.075), pm(0.078, -0.082)], 0.0),
           ([pm(0.018, -0.047), pm(0.04, -0.052), pm(0.06, -0.056)], 0.010),
           ([pm(0.02, 0.093), pm(0.06, 0.088), pm(0.095, 0.062)], 0.0)]
    fmid = None
    for k, (pts, lift) in enumerate(fil):
        path = []
        for u in range(13):
            t = u/12
            a, b, c = pts
            x = (1-t)**2*a[0]+2*(1-t)*t*b[0]+t*t*c[0]
            y = (1-t)**2*a[1]+2*(1-t)*t*b[1]+t*t*c[1]
            path.append((x, y, zf+lift*4*t*(1-t)))
        mesh_object(f'filamento {k}', 'citoesqueleto', tube(path, fr, 8), M['citoesqueleto'])
        if k == 0:
            fmid = path[6]
    parts['citoesqueleto'] = {'label_position': [fmid[0], fmid[1], fmid[2]+fr+0.001]}

    return {
        'title': 'Célula animal · detalle (R3)',
        'design_notes': [
            'Envoltura abierta por arriba con labio inclinado hacia el frente; piso de citosol bajo.',
            'Núcleo abierto con nucleoplasma y nucléolo visible; RER junto al núcleo, Golgi más lejos.',
            'Tres mitocondrias (una abierta con crestas), lisosomas, vesículas, centriolos en T y filamentos escasos.',
            'Dimensión X ajustada con los vértices reales a 0.300 m; sin pared celular ni vacuola central.',
        ],
        'parts': parts,
    }
